# Vorlesungsinhalte: Interviews in UX Design

## 1. Begrüßung und Einführung

### 1.1 Vorstellung des Dozenten
- Kurze Vorstellung mit relevanter Erfahrung im Bereich UX Design und Forschungsmethoden
- Hintergrund in der Anwendung von Interviewtechniken in verschiedenen UX-Projekten

### 1.2 Überblick über die Vorlesung
- Vorstellung der Agenda und des Zeitplans
- Erklärung des Formats: Theorie, Praxisbeispiele, Diskussionen
- Hinweis auf Pausen und interaktive Elemente

### 1.3 Lernziele
- Verständnis verschiedener Interviewmethoden im UX Design und ihrer Anwendungsbereiche
- Fähigkeit, Interviews in den UX-Prozess und in agile Entwicklungsumgebungen zu integrieren
- Kompetenz in der Planung, Durchführung und Analyse von Interviews
- Kenntnis typischer Herausforderungen und Best Practices
- Einblick in innovative Ansätze und zukünftige Entwicklungen

### 1.4 Relevanz des Themas für UX Design
- Interviews als fundamentale Methode zur Erfassung von Nutzerbedürfnissen und -erfahrungen
- Bedeutung qualitativer Daten für nutzerzentriertes Design
- Aktuelle Trends und die wachsende Bedeutung von Interviews in der UX-Praxis

## 2. Grundlagen von Interviews in UX Design

### 2.1 Definition und Zweck von Interviews in UX Design
Interviews im UX-Kontext sind strukturierte oder semi-strukturierte Gespräche mit Nutzern oder Stakeholdern, die darauf abzielen, tiefere Einblicke in Bedürfnisse, Verhaltensweisen, Einstellungen und Erfahrungen zu gewinnen. Sie dienen mehreren Zwecken:

- Erfassung von Nutzerbedürfnissen und -anforderungen
- Verständnis des Nutzungskontexts
- Identifikation von Problemen und Schmerzpunkten
- Validierung von Design-Hypothesen
- Sammlung von Feedback zu bestehenden oder geplanten Produkten

Im Gegensatz zu quantitativen Methoden ermöglichen Interviews tiefere Einblicke in die "Warum"-Fragen hinter dem Nutzerverhalten (Lanius et al., 2021).

### 2.2 Historische Entwicklung von Interviewmethoden
Die Entwicklung von Interviewmethoden im UX-Bereich hat ihre Wurzeln in verschiedenen Disziplinen:

- **1970er-1980er**: Einfluss der Kognitionspsychologie und Ergonomie auf frühe Usability-Methoden
- **1990er**: Aufkommen kontextueller Interviews durch Beyer und Holtzblatt (1998) mit ihrem "Contextual Design"-Ansatz
- **2000er**: Erweiterung von Usability zu User Experience; Interviews fokussieren zunehmend auf emotionale und experienzielle Aspekte
- **2010er**: Integration von Interviews in agile Entwicklungsprozesse; Entwicklung spezialisierter Methoden wie Critical Experience Interviews (Mannonen et al., 2014)
- **2020er**: Einfluss von KI und Remote-Technologien auf Interviewmethoden; Experimente mit simulierten Interviews (Barambones et al., 2024)

### 2.3 Einordnung von Interviews in den UX-Prozess
Interviews können in verschiedenen Phasen des UX-Prozesses eingesetzt werden:

- **Forschungsphase**: Erfassung von Nutzerbedürfnissen, Kontextanalyse, Persona-Entwicklung
- **Konzeptphase**: Validierung von Ideen, Feedback zu frühen Konzepten
- **Design- und Entwicklungsphase**: Iteratives Feedback zu Prototypen, Verständnis von Designentscheidungen
- **Evaluationsphase**: Bewertung der Nutzererfahrung, Identifikation von Verbesserungspotentialen
- **Post-Launch-Phase**: Erfassung langfristiger Nutzererfahrungen, Identifikation neuer Anforderungen

Die Integration von Interviews in den UX-Prozess sollte flexibel und an die spezifischen Projektziele angepasst sein (Cajander et al., 2022).

### 2.4 Unterschiede zu anderen Forschungsmethoden
Interviews bieten spezifische Vor- und Nachteile im Vergleich zu anderen UX-Forschungsmethoden:

| Methode | Vorteile | Nachteile | Komplementarität mit Interviews |
|---------|----------|-----------|--------------------------------|
| **Umfragen** | Große Stichproben, quantifizierbare Daten | Oberflächlich, keine Nachfragen möglich | Interviews können Umfrageergebnisse vertiefen und erklären |
| **Usability-Tests** | Beobachtung tatsächlichen Verhaltens | Fokus auf Interaktion, weniger auf Kontext | Interviews können Beobachtungen aus Tests kontextualisieren |
| **Feldbeobachtungen** | Natürliches Umfeld, reales Verhalten | Zeitaufwändig, interpretationsbedürftig | Interviews können beobachtetes Verhalten erklären |
| **Tagebuchstudien** | Longitudinale Daten, Alltagskontext | Abhängig von Selbstdokumentation | Interviews können Tagebucheinträge vertiefen |
| **Fokusgruppen** | Gruppendynamik, effizient | Gruppendruck, dominante Teilnehmer | Einzelinterviews können sensiblere Themen abdecken |

Die Kombination von Interviews mit anderen Methoden in einem Mixed-Methods-Ansatz wird in der zeitgenössischen UX-Forschung bevorzugt (Lanius et al., 2021).

### 2.5 Ethische Aspekte bei der Durchführung von Interviews
Bei der Durchführung von Interviews sind verschiedene ethische Aspekte zu beachten:

- **Informierte Einwilligung**: Teilnehmer müssen über Zweck, Dauer und Verwendung der Daten informiert werden
- **Vertraulichkeit und Datenschutz**: Sichere Speicherung und Anonymisierung persönlicher Daten
- **Respektvoller Umgang**: Wertschätzende Haltung gegenüber den Teilnehmern und ihren Perspektiven
- **Vermeidung von Bias**: Bewusstsein für eigene Vorurteile und deren möglichen Einfluss auf Fragen und Interpretation
- **Angemessene Vergütung**: Faire Entschädigung für die Zeit und den Beitrag der Teilnehmer
- **Recht auf Abbruch**: Teilnehmer müssen jederzeit das Interview beenden können

Die Einhaltung ethischer Standards ist nicht nur aus moralischen Gründen wichtig, sondern trägt auch zur Qualität der erhobenen Daten bei.

## 3. Interviewmethoden im Detail

### 3.1 Critical Experience Interviews
#### 3.1.1 Theoretischer Hintergrund und Adaption der CDM
Die Critical Experience Interview-Methode wurde von Mannonen et al. (2014) als Adaption der Critical Decision-Making Method (CDM) entwickelt. Die CDM stammt ursprünglich aus der Forschung zu Entscheidungsprozessen in Hochrisikobereichen und wurde für die Analyse von Expertenwissen eingesetzt.

Die Adaption für UX-Forschung behält die Grundstruktur der CDM bei, verschiebt jedoch den Fokus von Entscheidungsprozessen auf experienzielle und emotionale Aspekte der Nutzererfahrung. Diese Anpassung ermöglicht es, tiefere Einblicke in die subjektiven Erfahrungen der Nutzer zu gewinnen.

#### 3.1.2 Fokus auf experienzielle und emotionale Faktoren
Im Gegensatz zu traditionellen Interviewmethoden, die oft auf funktionale Aspekte oder Usability-Probleme fokussieren, konzentrieren sich Critical Experience Interviews auf:

- Emotionale Reaktionen und deren Auslöser
- Subjektive Bedeutungszuschreibungen
- Kontextuelle Faktoren, die die Erfahrung beeinflussen
- Implizites Wissen und unbewusste Reaktionen
- Langfristige Auswirkungen auf die Gesamterfahrung

Dieser Fokus ermöglicht ein tieferes Verständnis der Nutzererfahrung jenseits oberflächlicher Bewertungen (Mannonen et al., 2014).

#### 3.1.3 Multiple Perspektiven und iterative Interviewstrategie
Ein Schlüsselmerkmal der Critical Experience Interviews ist der Einsatz multipler Perspektiven und einer iterativen Interviewstrategie:

1. **Erste Durchlaufphase**: Identifikation kritischer Erfahrungen aus Nutzerperspektive
2. **Vertiefungsphase**: Detaillierte Exploration ausgewählter Erfahrungen
3. **Perspektivwechsel**: Betrachtung der Erfahrung aus verschiedenen Blickwinkeln
4. **Iterative Verfeinerung**: Wiederholte Befragung zur Validierung und Vertiefung

Diese Strategie ermöglicht es, über offensichtliche Antworten hinauszugehen und tiefere Schichten der Nutzererfahrung zu erschließen.

#### 3.1.4 Anwendungsbeispiele aus der Industrie
Mannonen et al. (2014) haben die Critical Experience Interview-Methode erfolgreich im Kontext der Prozessindustrie angewendet. Weitere Anwendungsbeispiele umfassen:

- Evaluation von Bedienschnittstellen in Kontrollräumen
- Untersuchung der Nutzererfahrung mit komplexen Softwaresystemen
- Analyse von Arbeitserfahrungen in sicherheitskritischen Umgebungen
- Erforschung emotionaler Reaktionen auf neue Technologien

Die Methode hat sich besonders in Kontexten bewährt, in denen tiefere Einblicke in komplexe Erfahrungen erforderlich sind.

### 3.2 Strukturierte Interviews im Goal-Directed Design
#### 3.2.1 Integration in den GDD-Prozess
Goal-Directed Design (GDD), entwickelt von Cooper, ist ein nutzerzentrierter Designansatz, der die Ziele der Nutzer in den Mittelpunkt stellt. Strukturierte Interviews spielen eine zentrale Rolle in diesem Prozess, insbesondere in der Forschungsphase.

Subiyakto et al. (2020) beschreiben, wie strukturierte Interviews in den GDD-Prozess integriert werden:

1. **Voruntersuchungsphase**: Interviews zur Identifikation von Nutzerzielen und -bedürfnissen
2. **Modellierungsphase**: Nutzung der Interviewdaten zur Erstellung von Personas und Szenarien
3. **Anforderungsphase**: Ableitung von Anforderungen aus den identifizierten Zielen
4. **Framework-Phase**: Entwicklung von Designlösungen basierend auf den Anforderungen
5. **Verfeinerungsphase**: Iterative Verbesserung durch weiteres Feedback
6. **Support-Phase**: Kontinuierliche Evaluation und Anpassung

Die strukturierten Interviews bilden das Fundament für den gesamten nachfolgenden Designprozess.

#### 3.2.2 Sechs-Phasen-Ansatz
Der von Subiyakto et al. (2020) beschriebene Sechs-Phasen-Ansatz für GDD umfasst spezifische Interviewtechniken in jeder Phase:

1. **Voruntersuchung**: Kombination aus strukturierten Interviews, kognitiven Walkthroughs und System Usability Scale (SUS)
2. **Modellierung**: Nutzung von Interviewdaten zur Erstellung von Nutzermodellen
3. **Anforderungen**: Ableitung konkreter Anforderungen aus Interviewergebnissen
4. **Frameworks**: Entwicklung von Design-Frameworks basierend auf Nutzerzielen
5. **Verfeinerung**: Iterative Verbesserung durch weitere Interviews und Feedback
6. **Support**: Kontinuierliche Evaluation durch Follow-up-Interviews

Dieser strukturierte Ansatz gewährleistet, dass die Designentscheidungen durchgängig auf Nutzerzielen basieren.

#### 3.2.3 Kombination mit anderen Methoden
Ein Schlüsselmerkmal des GDD-Ansatzes ist die Kombination strukturierter Interviews mit anderen Methoden:

- **Kognitive Walkthroughs**: Ergänzung der Interviews durch systematische Evaluation der Benutzeroberfläche
- **System Usability Scale (SUS)**: Quantitative Messung der Usability als Ergänzung zu qualitativen Interviewdaten
- **Personas und Szenarien**: Verdichtung der Interviewdaten in konkrete Nutzermodelle und Anwendungsfälle
- **Prototyping**: Umsetzung der aus Interviews gewonnenen Erkenntnisse in testbare Designs

Diese Kombination ermöglicht eine umfassendere Erfassung der Nutzerbedürfnisse und eine solidere Grundlage für Designentscheidungen.

### 3.3 Interviews für Persona-Erstellung
#### 3.3.1 Ziele und Struktur
Interviews zur Persona-Erstellung zielen darauf ab, repräsentative Nutzertypen zu identifizieren und zu charakterisieren. Barambones et al. (2024) beschreiben folgende Ziele:

- Sammlung demografischer Daten
- Erfassung von Zielen, Bedürfnissen und Schmerzpunkten
- Identifikation von Verhaltensmustern und Präferenzen
- Verständnis des Nutzungskontexts und der Umgebungsfaktoren
- Erfassung von Einstellungen und Werten

Die Struktur solcher Interviews umfasst typischerweise:

1. **Einführung und Hintergrund**: Demografische und kontextuelle Informationen
2. **Ziele und Motivationen**: Primäre und sekundäre Ziele der Nutzer
3. **Verhaltensweisen und Gewohnheiten**: Typische Nutzungsmuster
4. **Schmerzpunkte und Herausforderungen**: Probleme und Frustrationen
5. **Wünsche und Bedürfnisse**: Ideale Lösungen aus Nutzersicht

#### 3.3.2 Vom Interview zur Persona
Der Prozess der Transformation von Interviewdaten zu Personas umfasst mehrere Schritte:

1. **Datensammlung**: Durchführung der Interviews mit verschiedenen Nutzertypen
2. **Kodierung und Analyse**: Identifikation von Mustern und Gemeinsamkeiten
3. **Segmentierung**: Gruppierung ähnlicher Nutzer basierend auf Verhaltensmustern
4. **Charakterisierung**: Entwicklung repräsentativer Personas für jedes Segment
5. **Validierung**: Überprüfung der Personas auf Plausibilität und Repräsentativität
6. **Dokumentation**: Erstellung detaillierter Persona-Profile

Barambones et al. (2024) betonen die Bedeutung strukturierter Interviews für vergleichbare Ergebnisse, die eine solide Grundlage für die Persona-Erstellung bilden.

#### 3.3.3 Validierung von Personas
Die Validierung von Personas ist ein kritischer Schritt, um sicherzustellen, dass sie tatsächlich repräsentativ für die Zielgruppe sind:

- **Interne Validierung**: Überprüfung durch das Forschungsteam auf Konsistenz und Plausibilität
- **Stakeholder-Validierung**: Feedback von Projektbeteiligten und Domänenexperten
- **Nutzer-Validierung**: Überprüfung durch Mitglieder der Zielgruppe
- **Daten-Triangulation**: Abgleich mit quantitativen Daten und anderen Forschungsergebnissen
- **Iterative Verfeinerung**: Kontinuierliche Anpassung basierend auf neuem Feedback

Eine gründliche Validierung stellt sicher, dass die Personas als zuverlässige Grundlage für Designentscheidungen dienen können.

## 4. Anwendung von Interviews in der UX-Praxis

### 4.1 Interviews als Teil von Mixed-Methods-Ansätzen
#### 4.1.1 Kombination mit Usability-Tests
Die Kombination von Interviews mit Usability-Tests ist ein häufig angewandter Mixed-Methods-Ansatz in der UX-Forschung. Lanius et al. (2021) identifizieren folgende Integrationsmöglichkeiten:

- **Pre-Test-Interviews**: Erfassung von Erwartungen und Vorerfahrungen vor dem Test
- **Begleitende Interviews**: Think-Aloud-Protokolle während des Tests
- **Post-Test-Interviews**: Vertiefung der Beobachtungen und Erfassung subjektiver Eindrücke
- **Retrospektive Interviews**: Nachträgliche Reflexion über die Testerfahrung

Diese Kombination ermöglicht es, sowohl das beobachtbare Verhalten als auch die zugrundeliegenden Gedanken und Gefühle zu erfassen.

#### 4.1.2 Triangulation von Daten
Triangulation bezeichnet die Verwendung mehrerer Methoden, um ein umfassenderes Bild zu erhalten. Im UX-Kontext kann die Triangulation von Interviewdaten mit anderen Datenquellen erfolgen:

- **Methodentriangulation**: Kombination von Interviews mit quantitativen Methoden (z.B. Umfragen, Metriken)
- **Datentriangulation**: Vergleich von Interviewdaten verschiedener Teilnehmergruppen
- **Forschertriangulation**: Analyse der Interviewdaten durch mehrere Forscher
- **Theorietriangulation**: Interpretation der Daten aus verschiedenen theoretischen Perspektiven

Lanius et al. (2021) betonen, dass die zeitgenössische UX-Forschung zunehmend auf Triangulation setzt, um robustere Ergebnisse zu erzielen.

#### 4.1.3 Vor- und Nachteile verschiedener Kombinationen
Verschiedene Kombinationen von Interviews mit anderen Methoden bieten spezifische Vor- und Nachteile:

| Kombination | Vorteile | Nachteile |
|-------------|----------|-----------|
| **Interviews + Umfragen** | Breite und Tiefe; quantitative Validierung qualitativer Erkenntnisse | Methodischer Aufwand; potenzielle Inkonsistenzen |
| **Interviews + Usability-Tests** | Verhalten und Motivation; objektive und subjektive Daten | Zeitaufwand; komplexe Analyse |
| **Interviews + Feldbeobachtungen** | Kontextreiche Daten; Vergleich von Aussagen und Verhalten | Sehr zeitintensiv; große Datenmenge |
| **Interviews + Logdaten-Analyse** | Kombination von Selbstauskunft und tatsächlichem Nutzungsverhalten | Technischer Aufwand; Datenschutzbedenken |
| **Interviews + Tagebuchstudien** | Momentane und reflektierte Erfahrungen; Zeitverlauf | Hoher Aufwand für Teilnehmer; Abbruchquote |

Die Wahl der optimalen Kombination sollte sich an den spezifischen Forschungsfragen und verfügbaren Ressourcen orientieren.

### 4.2 Integration in agile Entwicklungsumgebungen
#### 4.2.1 Herausforderungen und Lösungsansätze
Die Integration von Interviews in agile Entwicklungsumgebungen stellt UX-Fachleute vor spezifische Herausforderungen. Cajander et al. (2022) identifizieren folgende Probleme und mögliche Lösungsansätze:

| Herausforderung | Lösungsansatz |
|-----------------|---------------|
| **Zeitdruck und kurze Sprints** | Fokussierte Micro-Interviews; kontinuierliche Rekrutierung |
| **Fehlende Planung für UX-Aktivitäten** | UX-Arbeit in eigenen Sprints; Vorlaufsprints für Forschung |
| **Schwierige Integration in Entwicklungszyklen** | Parallele Tracks für UX und Entwicklung; klare Kommunikation der Ergebnisse |
| **Mangelndes Verständnis im Team** | Einbeziehung von Entwicklern in Interviews; gemeinsame Analyse |
| **Dokumentation und Wissenstransfer** | Leichtgewichtige Dokumentationsformate; regelmäßige Sharing-Sessions |

Die erfolgreiche Integration erfordert sowohl methodische Anpassungen als auch organisatorische Veränderungen.

#### 4.2.2 Zeitliche Planung und Ressourcenallokation
Für die effektive Integration von Interviews in agile Prozesse ist eine durchdachte zeitliche Planung und Ressourcenallokation entscheidend:

- **Sprint-Planung**: Frühzeitige Einplanung von Interviews in den Sprint-Rhythmus
- **Zeitbudget**: Realistische Einschätzung des Zeitbedarfs für Vorbereitung, Durchführung und Analyse
- **Ressourcenzuweisung**: Klare Verantwortlichkeiten und ausreichende Kapazitäten
- **Priorisierung**: Fokus auf die wichtigsten Forschungsfragen bei begrenzten Ressourcen
- **Kontinuierliche Rekrutierung**: Aufbau eines Teilnehmerpools für schnellen Zugriff

Cajander et al. (2022) betonen, dass UX-Fachleute unter Zeitdruck oft zu Methoden greifen, die sie bereits kennen und die schnelle Ergebnisse liefern.

#### 4.2.3 Kommunikation der Ergebnisse im agilen Team
Die effektive Kommunikation von Interviewergebnissen im agilen Team ist entscheidend für deren Wirksamkeit:

- **Kurze, fokussierte Berichte**: Konzentration auf die wichtigsten Erkenntnisse und Implikationen
- **Visuelle Darstellung**: Nutzung von Visualisierungen zur schnellen Erfassung der Ergebnisse
- **Storytelling**: Präsentation der Ergebnisse in Form von Nutzergeschichten
- **Gemeinsame Analysesessions**: Einbeziehung des Teams in die Interpretation der Daten
- **Kontinuierliches Feedback**: Regelmäßige Updates statt umfassender Abschlussberichte

Diese Kommunikationsstrategien helfen, die Akzeptanz und Nutzung der Interviewergebnisse im agilen Team zu fördern.

### 4.3 Fallbeispiele aus der Praxis
#### 4.3.1 Erfolgreiche Anwendungen
Aus der Literatur und Praxis lassen sich verschiedene erfolgreiche Anwendungen von Interviews im UX-Kontext identifizieren:

**Fallbeispiel 1: Redesign einer Intranet-Plattform**
Barambones et al. (2024) beschreiben ein Projekt zur Neugestaltung eines Universitäts-Intranets, bei dem strukturierte Interviews mit 122 Nutzern durchgeführt wurden. Diese Interviews bildeten die Grundlage für die Entwicklung von acht Personas, die den gesamten Designprozess leiteten. Die klare Strukturierung der Interviews ermöglichte vergleichbare Ergebnisse und eine effiziente Analyse.

**Fallbeispiel 2: UX-Optimierung in der Prozessindustrie**
Mannonen et al. (2014) wendeten Critical Experience Interviews an, um die Nutzererfahrung in der Prozessindustrie zu untersuchen. Durch den Fokus auf experienzielle und emotionale Faktoren konnten sie tiefere Einblicke in die Arbeitserfahrungen gewinnen und konkrete Verbesserungsvorschläge für die Bedienschnittstellen entwickeln.

**Fallbeispiel 3: Agile UX in der Softwareentwicklung**
Cajander et al. (2022) beschreiben, wie UX-Fachleute in agilen Teams Interviews in ihren Workflow integrieren. Durch die Anpassung der Interviewmethoden an den Sprint-Rhythmus und die Entwicklung leichtgewichtiger Dokumentationsformate konnten sie trotz Zeitdruck wertvolle Nutzereinsichten gewinnen und in den Entwicklungsprozess einfließen lassen.

#### 4.3.2 Lessons Learned
Aus den Fallbeispielen lassen sich wichtige Erkenntnisse ableiten:

- **Methodische Anpassung**: Erfolgreiche Anwendungen passen Interviewmethoden an den spezifischen Kontext an
- **Klare Fokussierung**: Konzentration auf die wichtigsten Forschungsfragen bei begrenzten Ressourcen
- **Integration in den Gesamtprozess**: Frühzeitige Planung der Integration von Interviews in den Design- und Entwicklungsprozess
- **Teamübergreifende Zusammenarbeit**: Einbeziehung verschiedener Stakeholder in Planung und Auswertung
- **Iteratives Vorgehen**: Kontinuierliche Verfeinerung der Interviewmethoden basierend auf Erfahrungen

Diese Lessons Learned können als Orientierung für die eigene Anwendung von Interviews in UX-Projekten dienen.

## 5. Planung und Durchführung von Interviews

### 5.1 Vorbereitung
#### 5.1.1 Festlegung der Forschungsziele
Die klare Definition der Forschungsziele ist der erste und entscheidende Schritt bei der Planung von Interviews:

- **Spezifische Forschungsfragen**: Konkrete, beantwortbare Fragen formulieren
- **Priorisierung**: Wichtigste Fragen identifizieren, falls Zeit begrenzt ist
- **Abstimmung mit Stakeholdern**: Sicherstellen, dass die Ziele den Projektanforderungen entsprechen
- **Operationalisierung**: Übersetzung abstrakter Ziele in konkrete Interviewfragen
- **Realistische Erwartungen**: Einschätzung, welche Erkenntnisse durch Interviews gewonnen werden können

Die Forschungsziele sollten SMART sein: Spezifisch, Messbar, Akzeptiert, Realistisch und Terminiert.

#### 5.1.2 Auswahl der Teilnehmer
Die sorgfältige Auswahl der Interviewteilnehmer ist entscheidend für die Qualität der Ergebnisse:

- **Zielgruppenbestimmung**: Klare Definition der relevanten Nutzergruppen
- **Rekrutierungskriterien**: Entwicklung spezifischer Ein- und Ausschlusskriterien
- **Stichprobengröße**: Bestimmung der angemessenen Anzahl von Interviews (typischerweise 5-15 pro Nutzergruppe)
- **Rekrutierungskanäle**: Identifikation geeigneter Wege zur Teilnehmergewinnung
- **Screening**: Entwicklung eines Screening-Prozesses zur Auswahl passender Teilnehmer
- **Incentives**: Festlegung angemessener Vergütung oder anderer Anreize

Eine diverse und repräsentative Teilnehmergruppe ist wichtig, um ein umfassendes Bild zu erhalten.

#### 5.1.3 Entwicklung des Interviewleitfadens
Der Interviewleitfaden strukturiert das Gespräch und stellt sicher, dass alle relevanten Themen abgedeckt werden:

- **Einleitung**: Begrüßung, Vorstellung, Erklärung des Zwecks, Einverständniserklärung
- **Aufwärmfragen**: Einfache Fragen zum Einstieg und Aufbau von Rapport
- **Hauptteil**: Kernfragen zu den Forschungszielen, logisch strukturiert
- **Abschluss**: Zusammenfassung, Dank, nächste Schritte

Bei der Entwicklung der Fragen sollten folgende Prinzipien beachtet werden:
- Offene statt geschlossene Fragen
- Neutrale Formulierungen ohne Suggestivcharakter
- Klare, verständliche Sprache ohne Fachjargon
- Logischer Aufbau vom Allgemeinen zum Spezifischen
- Flexibilität für Nachfragen und Vertiefungen

#### 5.1.4 Pilottests
Pilottests sind wichtig, um den Interviewleitfaden zu validieren und zu verbessern:

- **Durchführung**: Test des Leitfadens mit 1-2 Personen aus der Zielgruppe
- **Zeitmanagement**: Überprüfung der benötigten Zeit für das gesamte Interview
- **Verständlichkeit**: Identifikation unklarer oder missverständlicher Fragen
- **Fluss**: Bewertung des logischen Aufbaus und der Übergänge
- **Anpassung**: Überarbeitung des Leitfadens basierend auf den Erkenntnissen

Pilottests können auch dazu dienen, die eigenen Interviewfähigkeiten zu verbessern.

### 5.2 Durchführung
#### 5.2.1 Setting und Umgebung
Die Wahl des richtigen Settings und der Umgebung kann die Qualität der Interviews erheblich beeinflussen:

- **Physische Interviews**:
  - Ruhiger, störungsfreier Raum
  - Angenehme Atmosphäre
  - Sitzanordnung auf Augenhöhe
  - Aufnahmegeräte unauffällig platzieren
  - Getränke und ggf. Snacks anbieten

- **Remote-Interviews**:
  - Stabile Internetverbindung sicherstellen
  - Geeignete Software mit Aufnahmefunktion
  - Vorab-Test der Technik
  - Minimierung von Hintergrundgeräuschen
  - Plan B für technische Probleme

- **Kontextuelle Interviews** (am Arbeitsplatz/zu Hause):
  - Minimale Störung der natürlichen Umgebung
  - Berücksichtigung von Datenschutz und Vertraulichkeit
  - Anpassung an den Arbeitsrhythmus des Teilnehmers
  - Mobile Aufnahmemöglichkeiten

Die Wahl des Settings sollte sich an den Forschungszielen und der Zielgruppe orientieren.

#### 5.2.2 Interviewtechniken und Fragetypen
Verschiedene Interviewtechniken und Fragetypen können eingesetzt werden, um unterschiedliche Arten von Informationen zu gewinnen:

**Interviewtechniken**:
- **Strukturierte Interviews**: Feste Reihenfolge und Formulierung der Fragen
- **Semi-strukturierte Interviews**: Leitfaden mit Flexibilität für Nachfragen
- **Unstrukturierte Interviews**: Offene Gespräche mit wenigen Leitfragen
- **Kontextuelle Interviews**: Beobachtung und Befragung im natürlichen Umfeld
- **Critical Incident Technique**: Fokus auf besonders positive oder negative Erfahrungen

**Fragetypen**:
- **Offene Fragen**: "Wie war Ihre Erfahrung mit...?"
- **Sondierungsfragen**: "Können Sie mehr darüber erzählen?"
- **Spezifische Fragen**: "Welche Funktion haben Sie zuerst genutzt?"
- **Hypothetische Fragen**: "Was würden Sie tun, wenn...?"
- **Verhaltensorientierte Fragen**: "Wie sind Sie vorgegangen, als...?"
- **Reflektierende Fragen**: "Warum glauben Sie, dass das passiert ist?"

Die Wahl der Techniken und Fragetypen sollte auf die Forschungsziele abgestimmt sein.

#### 5.2.3 Aktives Zuhören und Nachfragen
Aktives Zuhören und gezieltes Nachfragen sind entscheidend für tiefgehende Interviews:

**Aktives Zuhören**:
- Volle Aufmerksamkeit für den Teilnehmer
- Verbale Bestätigungen ("Ich verstehe", "Das ist interessant")
- Nonverbale Signale (Nicken, Blickkontakt)
- Paraphrasieren zur Verständnissicherung
- Pausen aushalten und nicht vorschnell füllen

**Nachfragetechniken**:
- **Vertiefungsfragen**: "Können Sie das genauer erklären?"
- **Klärungsfragen**: "Was meinen Sie genau mit...?"
- **Beispielfragen**: "Können Sie ein Beispiel dafür geben?"
- **Kontrastfragen**: "Wie unterscheidet sich das von...?"
- **Zusammenfassungen**: "Wenn ich Sie richtig verstehe, dann..."

Durch aktives Zuhören und gezieltes Nachfragen können tiefere Einblicke gewonnen und Missverständnisse vermieden werden.

#### 5.2.4 Umgang mit schwierigen Situationen
In Interviews können verschiedene Herausforderungen auftreten, die einen professionellen Umgang erfordern:

| Situation | Umgang |
|-----------|--------|
| **Einsilbige Antworten** | Offenere Fragen stellen, Beispiele geben, Stille aushalten |
| **Abschweifungen** | Höflich zum Thema zurückführen, Relevanz betonen |
| **Emotionale Reaktionen** | Empathie zeigen, Pause anbieten, Fortsetzung ermöglichen |
| **Technische Probleme** | Vorbereitet sein, Alternativen haben, Flexibilität zeigen |
| **Zeitdruck** | Priorisieren, transparent kommunizieren, ggf. Folgetermin vereinbaren |
| **Dominante Teilnehmer** | Höflich lenken, auf Forschungsziele fokussieren |
| **Zurückhaltende Teilnehmer** | Vertrauen aufbauen, einfachere Fragen stellen, Geduld zeigen |

Der professionelle Umgang mit schwierigen Situationen trägt wesentlich zur Qualität der Interviews bei.

### 5.3 Nachbereitung und Analyse
#### 5.3.1 Transkription und Kodierung
Die systematische Aufbereitung und Kodierung der Interviewdaten ist die Grundlage für eine fundierte Analyse:

**Transkription**:
- **Vollständige Transkription**: Wortgetreue Übertragung des gesamten Interviews
- **Selektive Transkription**: Übertragung relevanter Passagen
- **Zusammenfassende Transkription**: Inhaltliche Zusammenfassung mit Schlüsselzitaten
- **Automatisierte Transkription**: Nutzung von KI-Tools mit manueller Korrektur

**Kodierung**:
- **Offenes Kodieren**: Identifikation von Konzepten und Kategorien ohne vordefiniertes Schema
- **Axiales Kodieren**: Herstellung von Verbindungen zwischen Kategorien
- **Selektives Kodieren**: Fokussierung auf Kernkategorien und ihre Beziehungen
- **In-vivo-Kodierung**: Verwendung der Originalsprache der Teilnehmer als Codes

Die Wahl der Transkriptions- und Kodierungsmethode sollte sich an den Forschungszielen und verfügbaren Ressourcen orientieren.

#### 5.3.2 Qualitative Analysemethoden
Für die Analyse von Interviewdaten stehen verschiedene qualitative Methoden zur Verfügung:

- **Thematische Analyse**: Identifikation, Analyse und Dokumentation von Mustern (Themen) in den Daten
- **Grounded Theory**: Entwicklung einer Theorie aus den Daten durch iterative Kodierung und Analyse
- **Inhaltsanalyse**: Systematische Kategorisierung und Quantifizierung von Inhalten
- **Narrativanalyse**: Fokus auf die Struktur und den Inhalt von Erzählungen
- **Diskursanalyse**: Untersuchung von Sprache und Kommunikationsmustern
- **Affinity Diagramming**: Visuelle Gruppierung verwandter Konzepte und Ideen

Die Wahl der Analysemethode sollte auf die Forschungsfragen und den theoretischen Rahmen abgestimmt sein.

#### 5.3.3 Interpretation der Ergebnisse
Die Interpretation der Analyseergebnisse erfordert kritisches Denken und Reflexion:

- **Kontextualisierung**: Einordnung der Ergebnisse in den breiteren Forschungs- und Anwendungskontext
- **Musteridentifikation**: Erkennung wiederkehrender Themen und Zusammenhänge
- **Abweichungsanalyse**: Untersuchung von Ausnahmen und unerwarteten Ergebnissen
- **Triangulation**: Abgleich mit Ergebnissen aus anderen Methoden
- **Reflexive Interpretation**: Bewusstsein für eigene Vorannahmen und deren Einfluss
- **Validierung**: Überprüfung der Interpretationen durch Peer-Review oder Teilnehmer-Feedback

Eine sorgfältige Interpretation bildet die Grundlage für fundierte Design-Entscheidungen.

#### 5.3.4 Ableitung von Design-Implikationen
Die Übersetzung der Interviewergebnisse in konkrete Design-Implikationen ist ein entscheidender Schritt:

- **Bedürfnisidentifikation**: Ableitung konkreter Nutzerbedürfnisse aus den Interviewdaten
- **Anforderungsformulierung**: Übersetzung von Bedürfnissen in spezifische Anforderungen
- **Priorisierung**: Gewichtung der Anforderungen nach Wichtigkeit und Machbarkeit
- **Design-Prinzipien**: Entwicklung übergreifender Prinzipien als Leitlinien für das Design
- **Ideengenerierung**: Nutzung der Erkenntnisse als Inspiration für Design-Ideen
- **Validierungskriterien**: Ableitung von Kriterien zur späteren Evaluation des Designs

Die Design-Implikationen sollten direkt auf die Interviewdaten zurückführbar sein und einen klaren Mehrwert für den Designprozess bieten.

## 6. Herausforderungen und Best Practices

### 6.1 Typische Herausforderungen
#### 6.1.1 Zeitdruck und Ressourcenbeschränkungen
Zeitdruck und begrenzte Ressourcen sind in der UX-Praxis allgegenwärtig und beeinflussen die Durchführung von Interviews:

- **Zeitliche Einschränkungen**: Kurze Entwicklungszyklen, enge Deadlines, Sprint-Rhythmen
- **Personelle Ressourcen**: Begrenzte Verfügbarkeit von UX-Fachleuten für Forschungsaktivitäten
- **Budgetäre Einschränkungen**: Begrenzte Mittel für Teilnehmerrekrutierung und Incentives
- **Zugang zu Nutzern**: Schwierigkeiten bei der Rekrutierung geeigneter Teilnehmer

Cajander et al. (2022) zeigen, dass UX-Fachleute unter Zeitdruck oft zu bekannten Methoden greifen, die schnelle Ergebnisse liefern, was die methodische Innovation einschränken kann.

#### 6.1.2 Komplexität und Lernaufwand für neue Methoden
Die Aneignung neuer Interviewmethoden stellt UX-Fachleute vor Herausforderungen:

- **Steile Lernkurve**: Komplexe Methoden wie Critical Experience Interviews erfordern umfangreiche Einarbeitung
- **Fehlende Schulungsmöglichkeiten**: Begrenzte Zugänglichkeit von Trainings und Mentoring
- **Risiko bei Anwendung**: Unsicherheit bezüglich der Effektivität neuer Methoden im spezifischen Kontext
- **Dokumentationslücken**: Unzureichende praktische Anleitungen für die Implementierung

Diese Faktoren können dazu führen, dass innovative Methoden trotz ihres Potenzials in der Praxis wenig Anwendung finden.

#### 6.1.3 Integration in bestehende Prozesse
Die Integration von Interviews in bestehende Prozesse, insbesondere in agile Entwicklungsumgebungen, stellt eine Herausforderung dar:

- **Methodische Inkompatibilitäten**: Unterschiedliche Zeitskalen und Arbeitsweisen
- **Organisatorische Hürden**: Fehlende Verankerung von UX-Aktivitäten im Entwicklungsprozess
- **Kommunikationsprobleme**: Schwierigkeiten bei der Vermittlung qualitativer Erkenntnisse an technisch orientierte Teams
- **Wissenstransfer**: Herausforderungen bei der Weitergabe und Nutzung von Interviewerkenntnissen

Die erfolgreiche Integration erfordert sowohl methodische Anpassungen als auch organisatorische Veränderungen.

#### 6.1.4 Bias und Subjektivität
Interviews sind anfällig für verschiedene Formen von Bias und Subjektivität:

- **Interviewer-Bias**: Einfluss der eigenen Erwartungen und Vorannahmen auf Fragestellung und Interpretation
- **Soziale Erwünschtheit**: Tendenz der Teilnehmer, sozial akzeptable Antworten zu geben
- **Erinnerungsbias**: Ungenauigkeiten bei der Erinnerung an vergangene Ereignisse
- **Selektionsbias**: Verzerrungen durch nicht-repräsentative Teilnehmerauswahl
- **Bestätigungsbias**: Tendenz, Informationen zu suchen, die bestehende Annahmen bestätigen

Das Bewusstsein für diese Biases und der Einsatz geeigneter Gegenmaßnahmen sind entscheidend für die Qualität der Ergebnisse.

### 6.2 Best Practices
#### 6.2.1 Iterative Interviewstrategien
Iterative Interviewstrategien ermöglichen eine kontinuierliche Verbesserung und Anpassung:

- **Stufenweise Vertiefung**: Beginn mit breiten Fragen, schrittweise Vertiefung in späteren Interviews
- **Anpassung des Leitfadens**: Kontinuierliche Verfeinerung basierend auf gewonnenen Erkenntnissen
- **Zwischenanalysen**: Regelmäßige Auswertung zur Identifikation neuer Forschungsfragen
- **Validierungsinterviews**: Überprüfung vorläufiger Erkenntnisse in Folgeinterviews
- **Methodische Reflexion**: Kritische Bewertung und Anpassung der eigenen Vorgehensweise

Mannonen et al. (2014) betonen den Wert iterativer Strategien für die Gewinnung tieferer Einblicke in experienzielle Aspekte.

#### 6.2.2 Berücksichtigung multipler Perspektiven
Die Einbeziehung multipler Perspektiven bereichert die Interviewforschung:

- **Diverse Teilnehmergruppen**: Einbeziehung verschiedener Nutzertypen und Stakeholder
- **Interdisziplinäre Teams**: Zusammenarbeit von UX-Fachleuten mit anderen Disziplinen
- **Verschiedene Interviewkontexte**: Durchführung von Interviews in unterschiedlichen Umgebungen
- **Methodentriangulation**: Kombination von Interviews mit anderen Forschungsmethoden
- **Kollaborative Analyse**: Gemeinsame Interpretation der Daten durch verschiedene Teammitglieder

Die Berücksichtigung multipler Perspektiven trägt zur Robustheit und Validität der Ergebnisse bei.

#### 6.2.3 Strukturierte Interviews für vergleichbare Ergebnisse
Strukturierte Interviews bieten Vorteile für die Vergleichbarkeit und Effizienz:

- **Standardisierte Leitfäden**: Konsistente Fragen für alle Teilnehmer
- **Klare Kodierungsschemata**: Vordefinierte Kategorien für die Analyse
- **Systematische Dokumentation**: Einheitliche Protokollierung und Aufbereitung
- **Quantifizierbare Elemente**: Integration von Bewertungsskalen oder Priorisierungsaufgaben
- **Effiziente Auswertung**: Vereinfachte Analyse durch strukturierte Daten

Barambones et al. (2024) betonen die Bedeutung strukturierter Interviews für vergleichbare Ergebnisse bei der Persona-Erstellung.

#### 6.2.4 Integration in einen Mixed-Methods-Ansatz
Die Integration von Interviews in einen Mixed-Methods-Ansatz bietet zahlreiche Vorteile:

- **Komplementäre Stärken**: Ausgleich der Schwächen einzelner Methoden
- **Validierung**: Bestätigung von Erkenntnissen durch verschiedene Datenquellen
- **Tiefe und Breite**: Kombination tiefgehender qualitativer und breiterer quantitativer Daten
- **Kontextualisierung**: Einbettung von Interviewdaten in einen breiteren Forschungskontext
- **Überzeugungskraft**: Stärkere Evidenzbasis für Design-Entscheidungen

Lanius et al. (2021) zeigen, dass die zeitgenössische UX-Forschung zunehmend auf Mixed-Methods-Ansätze setzt.

### 6.3 Qualitätssicherung
#### 6.3.1 Validität und Reliabilität
Die Sicherstellung von Validität und Reliabilität ist entscheidend für die Qualität von Interviewstudien:

**Validität**:
- **Inhaltsvalidität**: Abdeckung aller relevanten Aspekte des Forschungsthemas
- **Konstruktvalidität**: Angemessene Operationalisierung der untersuchten Konzepte
- **Externe Validität**: Übertragbarkeit der Ergebnisse auf andere Kontexte
- **Ökologische Validität**: Relevanz für reale Nutzungskontexte

**Reliabilität**:
- **Interrater-Reliabilität**: Konsistenz zwischen verschiedenen Kodierern
- **Test-Retest-Reliabilität**: Stabilität der Ergebnisse bei wiederholten Interviews
- **Interne Konsistenz**: Kohärenz der Antworten innerhalb eines Interviews

Maßnahmen zur Sicherstellung von Validität und Reliabilität umfassen:
- Pilottests und Validierung der Interviewleitfäden
- Schulung der Interviewer
- Standardisierte Protokolle für Durchführung und Analyse
- Mehrfachkodierung durch verschiedene Forscher
- Dokumentation des methodischen Vorgehens

#### 6.3.2 Peer-Review und Triangulation
Peer-Review und Triangulation sind wichtige Strategien zur Qualitätssicherung:

**Peer-Review**:
- Überprüfung der Interviewleitfäden durch Kollegen
- Gemeinsame Analyse ausgewählter Interviews
- Kritische Diskussion der Interpretationen
- Feedback zu Schlussfolgerungen und Design-Implikationen

**Triangulation**:
- **Methodentriangulation**: Kombination verschiedener Forschungsmethoden
- **Datentriangulation**: Nutzung verschiedener Datenquellen
- **Forschertriangulation**: Einbeziehung mehrerer Forscher in die Analyse
- **Theorietriangulation**: Anwendung verschiedener theoretischer Perspektiven

Diese Strategien tragen dazu bei, blinde Flecken zu identifizieren und die Robustheit der Ergebnisse zu erhöhen.

#### 6.3.3 Dokumentation und Transparenz
Gründliche Dokumentation und Transparenz sind Grundpfeiler guter Forschungspraxis:

- **Methodische Dokumentation**: Detaillierte Beschreibung des Vorgehens
- **Entscheidungstransparenz**: Offenlegung von Entscheidungen und deren Begründung
- **Datenverwaltung**: Systematische Archivierung von Rohdaten und Analysen
- **Limitationen**: Ehrliche Darstellung der Grenzen der Studie
- **Reflexivität**: Kritische Reflexion des eigenen Einflusses auf den Forschungsprozess

Eine gründliche Dokumentation ermöglicht nicht nur die Nachvollziehbarkeit der Ergebnisse, sondern auch das Lernen aus Erfahrungen für zukünftige Projekte.

## 7. Innovative Ansätze und zukünftige Entwicklungen

### 7.1 KI-unterstützte Interviews
#### 7.1.1 Aktuelle Forschung
Die Nutzung von KI zur Unterstützung von Interviews ist ein aufstrebendes Forschungsfeld:

- **Simulierte Interviews**: Barambones et al. (2024) untersuchen den Einsatz von ChatGPT zur Simulation von Nutzerinterviews für Lernzwecke
- **Automatisierte Transkription und Analyse**: KI-gestützte Tools zur Verarbeitung von Interviewdaten
- **Interviewvorbereitung**: KI-Systeme zur Generierung von Interviewleitfäden und Fragen
- **Bias-Erkennung**: Algorithmen zur Identifikation potenzieller Verzerrungen in Fragestellungen
- **Adaptive Interviews**: KI-gesteuerte Anpassung von Fragen basierend auf vorherigen Antworten

Diese Forschungsrichtungen zeigen das Potenzial von KI zur Unterstützung und Erweiterung traditioneller Interviewmethoden.

#### 7.1.2 Potenziale und Grenzen
KI-unterstützte Interviews bieten spezifische Potenziale, stoßen jedoch auch an Grenzen:

**Potenziale**:
- Skalierbarkeit und Effizienz durch Automatisierung
- Konsistenz in der Durchführung
- Neue Analysemöglichkeiten durch maschinelles Lernen
- Reduzierung menschlicher Bias in bestimmten Kontexten
- Zugänglichkeit von Interviewtechniken für Lernende

**Grenzen**:
- Eingeschränkte Fähigkeit zur Erfassung nonverbaler Signale
- Mangel an echter Empathie und situativem Verständnis
- Potenzielle Verstärkung bestehender Biases in den Trainingsdaten
- Datenschutz- und Ethikbedenken
- Akzeptanzprobleme bei Teilnehmern

Barambones et al. (2024) zeigen, dass KI-simulierte Interviews als Lernwerkzeug nützlich sein können, weisen jedoch auf Probleme wie Antwortwiederholungen und geringe Variabilität hin.

#### 7.1.3 Ethische Überlegungen
Der Einsatz von KI in Interviews wirft wichtige ethische Fragen auf:

- **Transparenz**: Offenlegung des KI-Einsatzes gegenüber Teilnehmern
- **Datenschutz**: Sichere Verarbeitung und Speicherung sensibler Interviewdaten
- **Verantwortlichkeit**: Klärung der Verantwortung für KI-generierte Inhalte und Analysen
- **Bias und Fairness**: Vermeidung von Diskriminierung durch KI-Systeme
- **Menschliche Aufsicht**: Notwendigkeit menschlicher Kontrolle und Interpretation
- **Authentizität**: Fragen zur Authentizität simulierter Interviews und deren Ergebnisse

Eine verantwortungsvolle Nutzung von KI erfordert die kontinuierliche Auseinandersetzung mit diesen ethischen Aspekten.

### 7.2 Neue Technologien zur Unterstützung von Interviews
#### 7.2.1 Remote-Interviews und digitale Tools
Die Digitalisierung hat neue Möglichkeiten für die Durchführung von Interviews geschaffen:

- **Videokonferenz-Plattformen**: Spezialisierte Tools für Remote-Interviews mit integrierten Aufnahme- und Analysefunktionen
- **Mobile Ethnographie**: Apps für kontextbezogene Interviews und Selbstdokumentation
- **Kollaborative Analyse-Tools**: Plattformen für die gemeinsame Kodierung und Interpretation von Interviewdaten
- **Automatisierte Rekrutierungstools**: Systeme zur effizienten Teilnehmergewinnung und -verwaltung
- **Integrierte Forschungsplattformen**: End-to-End-Lösungen für den gesamten Interviewprozess

Diese Tools erweitern die Möglichkeiten für Interviews und können deren Effizienz und Reichweite erhöhen.

#### 7.2.2 Automatisierte Analyse von Interviewdaten
Die automatisierte Analyse von Interviewdaten entwickelt sich rasch weiter:

- **Natural Language Processing (NLP)**: Automatische Identifikation von Themen und Sentiments
- **Automatische Kodierung**: KI-gestützte Kategorisierung von Interviewaussagen
- **Mustererkennungsalgorithmen**: Identifikation von Zusammenhängen und wiederkehrenden Themen
- **Visualisierungstools**: Automatische Generierung von Visualisierungen aus Interviewdaten
- **Prädiktive Analysen**: Vorhersage potenzieller Nutzerbedürfnisse basierend auf Interviewdaten

Diese Technologien können die Analyse beschleunigen und neue Einblicke ermöglichen, erfordern jedoch weiterhin menschliche Interpretation und Validierung.

#### 7.2.3 Multimodale Datenerfassung
Die Erfassung multimodaler Daten während Interviews eröffnet neue Dimensionen:

- **Biometrische Messungen**: Erfassung physiologischer Reaktionen während des Interviews
- **Eye-Tracking**: Analyse der visuellen Aufmerksamkeit bei der Diskussion von Designs
- **Emotionserkennung**: Automatische Analyse von Gesichtsausdrücken und Stimmmodulation
- **Kontextdaten**: Integration von Umgebungsinformationen und Sensordaten
- **Virtual Reality (VR)**: Immersive Interviews in simulierten Umgebungen

Die multimodale Datenerfassung kann die Tiefe und Reichhaltigkeit der Interviewdaten erhöhen, stellt jedoch auch höhere Anforderungen an Datenschutz und Analyse.

### 7.3 Forschungstrends und zukünftige Richtungen
#### 7.3.1 Integration von UX-Interviews in agile Prozesse
Die verbesserte Integration von UX-Interviews in agile Prozesse ist ein wichtiger Forschungstrend:

- **Agile UX-Frameworks**: Entwicklung spezialisierter Frameworks für die Integration von UX-Forschung in agile Prozesse
- **Kontinuierliche Forschung**: Modelle für kontinuierliche, parallele UX-Forschung während der Entwicklung
- **Leichtgewichtige Methoden**: Entwicklung effizienter, an agile Zyklen angepasster Interviewmethoden
- **Kollaborative Ansätze**: Stärkere Einbeziehung von Entwicklungsteams in den Interviewprozess
- **Automatisierte Integration**: Tools zur nahtlosen Einbindung von Interviewerkenntnissen in agile Artefakte

Cajander et al. (2022) betonen die Notwendigkeit weiterer Forschung zur Überwindung der Herausforderungen bei der Integration von UX-Methoden in agile Prozesse.

#### 7.3.2 Entwicklung effizienterer Interviewmethoden
Die Entwicklung effizienterer Interviewmethoden ist ein zentrales Anliegen für die Praxis:

- **Micro-Interviews**: Kurze, fokussierte Interviews zu spezifischen Aspekten
- **Modulare Ansätze**: Flexible, kombinierbare Interviewmodule für verschiedene Kontexte
- **Automatisierte Vorbereitung**: KI-gestützte Generierung von Interviewleitfäden
- **Streamlined Analysis**: Vereinfachte, teilautomatisierte Analyseprozesse
- **Integrierte Dokumentation**: Effiziente Dokumentationsformate für schnelle Kommunikation

Cajander et al. (2022) zeigen, dass UX-Fachleute unter Zeitdruck effiziente Methoden bevorzugen, die schnelle Ergebnisse liefern.

#### 7.3.3 Kulturelle und kontextuelle Faktoren
Die Berücksichtigung kultureller und kontextueller Faktoren gewinnt zunehmend an Bedeutung:

- **Kulturübergreifende Interviewmethoden**: Anpassung von Techniken an verschiedene kulturelle Kontexte
- **Inklusive Forschung**: Entwicklung von Methoden für diverse und unterrepräsentierte Nutzergruppen
- **Kontextsensitive Ansätze**: Berücksichtigung spezifischer Nutzungskontexte in der Interviewgestaltung
- **Globale Forschungsteams**: Methoden für die Zusammenarbeit verteilter, multikultureller Teams
- **Lokalisierte Praktiken**: Anpassung von Interviewpraktiken an lokale Gegebenheiten und Normen

Die Forschung zu diesen Faktoren trägt dazu bei, Interviewmethoden inklusiver und global anwendbarer zu machen.

## 8. Zusammenfassung und Ausblick

### 8.1 Kernpunkte der Vorlesung
Die wichtigsten Erkenntnisse dieser Vorlesung lassen sich wie folgt zusammenfassen:

1. **Vielfalt der Methoden**: Interviews im UX-Design umfassen verschiedene Ansätze, von Critical Experience Interviews über strukturierte Interviews im Goal-Directed Design bis hin zu Interviews für die Persona-Erstellung.

2. **Integration in den UX-Prozess**: Interviews können in allen Phasen des UX-Prozesses eingesetzt werden, von der frühen Forschung bis zur Evaluation und Post-Launch-Phase.

3. **Mixed-Methods-Ansätze**: Die Kombination von Interviews mit anderen Forschungsmethoden in einem Mixed-Methods-Ansatz wird in der zeitgenössischen UX-Forschung bevorzugt.

4. **Herausforderungen in agilen Umgebungen**: Die Integration von Interviews in agile Entwicklungsprozesse stellt besondere Herausforderungen dar, für die spezifische Lösungsansätze entwickelt wurden.

5. **Systematischer Prozess**: Erfolgreiche Interviews erfordern eine sorgfältige Planung, Durchführung und Analyse, wobei jede Phase spezifische Techniken und Best Practices umfasst.

6. **Qualitätssicherung**: Validität, Reliabilität, Peer-Review und Triangulation sind entscheidend für die Qualität von Interviewstudien.

7. **Innovative Ansätze**: KI-unterstützte Interviews, neue Technologien und multimodale Datenerfassung eröffnen neue Möglichkeiten für die UX-Forschung.

8. **Zukünftige Entwicklungen**: Die Forschung zu effizienteren Methoden, besserer Integration in agile Prozesse und kulturellen Faktoren wird die Zukunft von UX-Interviews prägen.

### 8.2 Weiterführende Ressourcen
Für die Vertiefung des Themas werden folgende Ressourcen empfohlen:

**Bücher**:
- Portigal, S. (2013). Interviewing Users: How to Uncover Compelling Insights. Rosenfeld Media.
- Baxter, K., Courage, C., & Caine, K. (2015). Understanding Your Users: A Practical Guide to User Research Methods. Morgan Kaufmann.
- Cooper, A., Reimann, R., Cronin, D., & Noessel, C. (2014). About Face: The Essentials of Interaction Design. Wiley.

**Wissenschaftliche Artikel**:
- Mannonen, P., Aikala, M., Koskinen, H., & Savioja, P. (2014). Uncovering the user experience with critical experience interviews.
- Barambones, J., Moral, C., de Antonio, A., Imbert, R., Martínez-Normand, L., & Villalba-Mora, E. (2024). ChatGPT for Learning HCI Techniques: A Case Study on Interviews for Personas.
- Cajander, Å., Larusdottir, M., & Geiser, J. L. (2022). UX professionals' learning and usage of UX methods in agile.

**Online-Ressourcen**:
- Nielsen Norman Group: [User Interviews: How, When, and Why to Conduct Them](https://www.nngroup.com/articles/user-interviews/)
- Interaction Design Foundation: [How to Conduct User Interviews](https://www.interaction-design.org/literature/article/how-to-conduct-user-interviews)
- UX Collective: [The Art of the User Interview](https://uxdesign.cc/the-art-of-the-user-interview-cf40d1ca62e8)

**Tools und Vorlagen**:
- Interviewleitfaden-Vorlagen für verschiedene Interviewtypen
- Analyse-Templates für die Kodierung und Interpretation von Interviewdaten
- Checklisten für die Planung und Durchführung von Interviews

### 8.3 Nächste Schritte für die praktische Anwendung
Für die praktische Anwendung des Gelernten werden folgende Schritte empfohlen:

1. **Methodenauswahl**: Basierend auf den spezifischen Forschungszielen und Rahmenbedingungen die geeignete Interviewmethode auswählen.

2. **Pilotprojekt**: Mit einem kleinen, überschaubaren Projekt beginnen, um Erfahrungen zu sammeln und die Methode zu erproben.

3. **Mentoring und Feedback**: Wenn möglich, erfahrene Kollegen um Feedback und Unterstützung bitten.

4. **Iterative Verbesserung**: Die eigene Interviewpraxis kontinuierlich reflektieren und verbessern.

5. **Methodenintegration**: Interviews in einen breiteren Mixed-Methods-Ansatz integrieren.

6. **Wissensaustausch**: Erfahrungen und Erkenntnisse mit der Community teilen, um zum kollektiven Wissen beizutragen.

7. **Weiterbildung**: Kontinuierlich über neue Entwicklungen und Methoden auf dem Laufenden bleiben.

### 8.4 Verbindung zu anderen UX-Methoden
Interviews stehen in enger Verbindung zu anderen UX-Methoden und können mit diesen kombiniert werden:

- **Usability-Tests**: Interviews können vor, während oder nach Usability-Tests durchgeführt werden, um Beobachtungen zu kontextualisieren und zu vertiefen.

- **Umfragen**: Interviews können zur Vertiefung von Umfrageergebnissen oder zur Vorbereitung von Umfragen eingesetzt werden.

- **Feldbeobachtungen**: Kontextuelle Interviews können mit Beobachtungen kombiniert werden, um ein umfassenderes Bild zu erhalten.

- **Personas und Szenarien**: Interviews liefern die Grundlage für die Entwicklung von Personas und Szenarien.

- **Customer Journey Maps**: Interviews können helfen, die emotionalen und experientiellen Aspekte von Customer Journeys zu erfassen.

- **Prototyping und Testing**: Interviews können zur Evaluation von Prototypen und zur Erfassung von Nutzerfeedback eingesetzt werden.

Die Integration von Interviews in einen umfassenden UX-Prozess maximiert ihren Wert und trägt zu fundierteren Design-Entscheidungen bei.

## 9. Fragen und Diskussion

### 9.1 Häufig gestellte Fragen
Hier sind Antworten auf häufig gestellte Fragen zu Interviews in UX Design:

**F: Wie viele Interviews sind ausreichend für ein UX-Projekt?**
A: Die optimale Anzahl hängt vom Projektumfang, der Heterogenität der Zielgruppe und den verfügbaren Ressourcen ab. Nielsen und Landauer (1993) argumentieren, dass bereits 5-8 Interviews pro Nutzergruppe etwa 80% der Erkenntnisse liefern können. Für komplexere Projekte oder heterogene Zielgruppen können jedoch mehr Interviews erforderlich sein.

**F: Wie kann ich sicherstellen, dass die Interviewergebnisse objektiv sind?**
A: Vollständige Objektivität ist kaum erreichbar, aber Maßnahmen wie standardisierte Protokolle, Peer-Review, Triangulation mit anderen Methoden und Bewusstsein für potenzielle Biases können die Objektivität erhöhen.

**F: Wie überzeuge ich Stakeholder vom Wert von Interviews?**
A: Zeigen Sie konkrete Beispiele, wie Interviewerkenntnisse zu besseren Design-Entscheidungen und letztlich zu erfolgreichen Produkten geführt haben. Quantifizieren Sie, wo möglich, den ROI durch vermiedene Entwicklungskosten oder verbesserte Nutzerzufriedenheit.

**F: Wie integriere ich Interviews in einen engen Zeitplan?**
A: Fokussieren Sie auf die wichtigsten Forschungsfragen, nutzen Sie effiziente Rekrutierungsstrategien, vereinfachen Sie die Analyse durch klare Fokussierung und ziehen Sie Micro-Interviews oder Remote-Methoden in Betracht.

**F: Wie gehe ich mit widersprüchlichen Interviewergebnissen um?**
A: Untersuchen Sie die Kontextfaktoren, die zu den Widersprüchen führen könnten, segmentieren Sie die Nutzer nach relevanten Kriterien und nutzen Sie Follow-up-Interviews oder andere Methoden zur Klärung.

### 9.2 Diskussionsthemen
Folgende Themen eignen sich für eine vertiefende Diskussion:

1. **Ethik und KI**: Welche ethischen Implikationen hat der Einsatz von KI-generierten Interviews für Forschungs- oder Lernzwecke?

2. **Quantitative vs. qualitative Ansätze**: Wie kann die richtige Balance zwischen qualitativen Interviews und quantitativen Methoden gefunden werden?

3. **Kulturelle Unterschiede**: Wie müssen Interviewmethoden an verschiedene kulturelle Kontexte angepasst werden?

4. **Remote vs. vor Ort**: Welche Vor- und Nachteile haben Remote-Interviews im Vergleich zu persönlichen Interviews, und wie kann man die Nachteile minimieren?

5. **Zukunft der UX-Interviews**: Wie werden sich Interviewmethoden in den nächsten 5-10 Jahren entwickeln, und welche Fähigkeiten werden UX-Forscher benötigen?

Diese Diskussionsthemen können je nach Interesse und Zeitrahmen ausgewählt und vertieft werden.

### 9.3 Feedback zur Vorlesung
Feedback zur Vorlesung kann in verschiedenen Formaten eingeholt werden:

- Offene Diskussion zu Stärken und Verbesserungspotentialen
- Schriftliches Feedback zu spezifischen Aspekten
- Bewertung der Relevanz und Nützlichkeit einzelner Themen
- Vorschläge für zusätzliche Themen oder Ressourcen

Das Feedback dient der kontinuierlichen Verbesserung der Vorlesung und der Anpassung an die Bedürfnisse der Teilnehmer.
