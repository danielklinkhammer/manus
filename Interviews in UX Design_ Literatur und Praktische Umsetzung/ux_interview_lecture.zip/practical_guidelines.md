# Praktische Handlungsanweisungen für Interviews im UX Design

Dieser Leitfaden bietet konkrete Handlungsanweisungen für die Planung, Durchführung und Analyse von Interviews im UX Design. Er ist als praktisches Hilfsmittel für UX-Forscher und Designer konzipiert und kann direkt in Projekten angewendet werden.

## 1. Planung von Interviews

### 1.1 Checkliste zur Vorbereitung von Interviews

#### Vor dem Projekt
- [ ] Forschungsziele klar definieren
- [ ] Passende Interviewmethode auswählen (strukturiert, semi-strukturiert, Critical Experience Interview etc.)
- [ ] Zeitplan und Budget festlegen
- [ ] Benötigte Ressourcen identifizieren (Aufnahmegeräte, Software, Räumlichkeiten)
- [ ] Ethische Richtlinien und Datenschutzanforderungen klären
- [ ] Einverständniserklärung vorbereiten

#### Teilnehmerrekrutierung
- [ ] Zielgruppe(n) definieren
- [ ] Ein- und Ausschlusskriterien festlegen
- [ ] Rekrutierungsstrategie entwickeln
- [ ] Screening-Fragebogen erstellen
- [ ] Incentives festlegen
- [ ] Teilnehmer kontaktieren und Termine vereinbaren
- [ ] Erinnerungen 24-48 Stunden vor dem Interview versenden

#### Interviewleitfaden
- [ ] Forschungsfragen in Interviewfragen übersetzen
- [ ] Logische Struktur entwickeln (Einleitung, Aufwärmfragen, Hauptteil, Abschluss)
- [ ] Offene Fragen formulieren
- [ ] Neutrale, nicht-suggestive Formulierungen verwenden
- [ ] Fachbegriffe vermeiden oder erklären
- [ ] Nachfragen und Prompts vorbereiten
- [ ] Zeitschätzung für jeden Abschnitt
- [ ] Pilottest mit 1-2 Personen durchführen und Leitfaden anpassen

### 1.2 Vorlage für einen Interviewleitfaden

```
# Interviewleitfaden: [Projektname]

## Metadaten
- Datum: 
- Interviewer:
- Teilnehmer-ID:
- Dauer: ca. [X] Minuten

## 1. Einleitung (ca. 5 Minuten)
- Begrüßung und Dank für die Teilnahme
- Vorstellung des Interviewers und des Projekts
  "Mein Name ist [Name], ich arbeite als [Rolle] bei [Organisation]. Wir führen diese Interviews durch, um [Zweck]."
- Erklärung des Ablaufs
  "Das Interview wird etwa [X] Minuten dauern. Ich werde Ihnen Fragen zu [Thema] stellen."
- Datenschutz und Einverständnis
  "Das Gespräch wird aufgezeichnet, um die Analyse zu erleichtern. Alle Informationen werden vertraulich behandelt und anonymisiert. Sie können jederzeit Pausen machen oder das Interview beenden."
- Fragen des Teilnehmers klären
  "Haben Sie noch Fragen, bevor wir beginnen?"

## 2. Aufwärmfragen (ca. 5-10 Minuten)
- Hintergrundinformationen zum Teilnehmer
  "Können Sie mir kurz etwas über sich und Ihre Rolle/Tätigkeit erzählen?"
- Allgemeine Erfahrungen zum Thema
  "Welche Erfahrungen haben Sie bereits mit [relevantes Thema]?"

## 3. Hauptteil (ca. 20-30 Minuten)
### Thema A: [Thema einfügen]
- Hauptfrage 1: "[Offene Frage zum Thema]"
  - Nachfrage 1.1: "[Vertiefende Frage]"
  - Nachfrage 1.2: "[Vertiefende Frage]"
- Hauptfrage 2: "[Offene Frage zum Thema]"
  - Nachfrage 2.1: "[Vertiefende Frage]"

### Thema B: [Thema einfügen]
- Hauptfrage 3: "[Offene Frage zum Thema]"
  - Nachfrage 3.1: "[Vertiefende Frage]"
- Hauptfrage 4: "[Offene Frage zum Thema]"
  - Nachfrage 4.1: "[Vertiefende Frage]"

## 4. Abschluss (ca. 5 Minuten)
- Zusammenfassung
  "Wir haben über [Hauptthemen] gesprochen. Gibt es etwas, das Sie noch ergänzen möchten?"
- Offene Frage
  "Gibt es etwas, das ich nicht gefragt habe, das aber wichtig sein könnte?"
- Dank und nächste Schritte
  "Vielen Dank für Ihre Zeit und Ihre Einblicke. Die Ergebnisse werden [Verwendungszweck]."
- Incentive-Übergabe und Verabschiedung

## Notizen für den Interviewer
- Bei Thema [X] besonders auf [Y] achten
- Falls [Situation Z] eintritt, [Handlungsanweisung]
```

### 1.3 Anpassung an verschiedene Interviewtypen

#### Für strukturierte Interviews
- Fragen exakt wie formuliert stellen
- Reihenfolge strikt einhalten
- Antwortoptionen vordefinieren (bei geschlossenen Fragen)
- Standardisierte Prompts für Nachfragen verwenden

#### Für semi-strukturierte Interviews
- Kernfragen als Leitfaden verwenden
- Flexibilität für Abweichungen und Vertiefungen einplanen
- Zusätzliche optionale Fragen vorbereiten
- Raum für spontane Nachfragen lassen

#### Für Critical Experience Interviews
- Fragen zur Identifikation kritischer Erfahrungen vorbereiten
- Mehrere Durchläufe mit zunehmender Tiefe planen
- Fragen zu emotionalen und experientiellen Aspekten einbauen
- Perspektivwechsel einplanen

#### Für kontextuelle Interviews
- Beobachtungsfragen integrieren
- Platz für Skizzen und Notizen zur Umgebung vorsehen
- Fragen zur Interaktion mit Artefakten vorbereiten
- Flexibilität für situative Anpassungen einplanen

## 2. Durchführung von Interviews

### 2.1 Schritt-für-Schritt-Anleitung zur Interviewdurchführung

#### Vorbereitung am Interviewtag
1. **Equipment überprüfen**
   - Aufnahmegerät/Software testen
   - Batterien/Ladezustand prüfen
   - Backup-Lösungen bereithalten
   - Interviewleitfaden ausdrucken oder digital bereitstellen

2. **Umgebung vorbereiten**
   - Ruhigen, störungsfreien Raum sicherstellen
   - Angenehme Temperatur und Beleuchtung
   - Wasser und ggf. Snacks bereitstellen
   - Sitzanordnung optimieren (90° oder gegenüber, je nach Präferenz)

3. **Mentale Vorbereitung**
   - Interviewleitfaden noch einmal durchgehen
   - Forschungsziele vergegenwärtigen
   - Neutrale, offene Haltung einnehmen
   - Kurze Entspannungsübung (optional)

#### Während des Interviews
1. **Begrüßung und Einführung (5 Minuten)**
   - Freundlich und professionell begrüßen
   - Projekt und Zweck des Interviews erklären
   - Datenschutz und Vertraulichkeit erläutern
   - Einverständniserklärung unterschreiben lassen
   - Aufnahme starten und testen

2. **Rapport aufbauen (5-10 Minuten)**
   - Mit leichten, angenehmen Fragen beginnen
   - Aktives Zuhören demonstrieren
   - Offene Körpersprache zeigen
   - Gemeinsame Basis finden (ohne Bias zu erzeugen)

3. **Hauptteil des Interviews (20-40 Minuten)**
   - Mit offenen Fragen beginnen
   - Von allgemeinen zu spezifischen Fragen übergehen
   - Aktiv zuhören und Blickkontakt halten
   - Pausen aushalten (3-5 Sekunden warten)
   - Nachfragen bei unklaren oder interessanten Punkten
   - Notizen zu wichtigen Punkten und non-verbalen Signalen machen

4. **Abschluss (5-10 Minuten)**
   - Wichtige Punkte zusammenfassen
   - Nach weiteren Gedanken oder Ergänzungen fragen
   - Für die Teilnahme danken
   - Nächste Schritte erläutern
   - Incentive übergeben
   - Aufnahme beenden

#### Nach dem Interview
1. **Unmittelbare Nachbereitung**
   - Kurze Reflexionsnotizen erstellen (5-10 Minuten)
   - Aufnahme sichern und Backup erstellen
   - Besondere Erkenntnisse oder Auffälligkeiten notieren
   - Interviewqualität bewerten

2. **Organisation**
   - Dateien systematisch benennen und ablegen
   - Teilnahmebestätigung dokumentieren
   - Nächste Interviews vorbereiten

### 2.2 Techniken für effektives Nachfragen

#### TEDW-Technik für Nachfragen
- **T**ell me more: "Können Sie mir mehr darüber erzählen?"
- **E**xplain: "Können Sie erklären, wie genau das funktioniert?"
- **D**escribe: "Beschreiben Sie bitte, wie Sie dabei vorgegangen sind."
- **W**hy: "Warum ist das für Sie wichtig?" (vorsichtig einsetzen)

#### Weitere effektive Nachfragetechniken
- **Spiegelung**: Letzte Worte oder Kernaussage wiederholen
  - "Sie sagten, es war frustrierend..."
- **Paraphrasierung**: Aussage in eigenen Worten zusammenfassen
  - "Wenn ich Sie richtig verstehe, dann..."
- **Konkretisierung**: Nach spezifischen Beispielen fragen
  - "Können Sie ein konkretes Beispiel dafür geben?"
- **Kontrastfragen**: Nach Unterschieden fragen
  - "Wie unterscheidet sich das von...?"
- **Hypothetische Fragen**: Alternative Szenarien erkunden
  - "Was würden Sie tun, wenn...?"

### 2.3 Umgang mit herausfordernden Situationen

#### Einsilbige Antworten
- Offenere Formulierungen verwenden
- Konkrete Beispiele als Anker anbieten
- Schweigen aushalten (3-5 Sekunden)
- Format wechseln (z.B. zu einer Aktivität)

#### Abschweifungen
- Höflich zum Thema zurückführen
  - "Das ist interessant. Lassen Sie uns noch einmal zu... zurückkehren."
- Relevanz betonen
  - "Um besser zu verstehen, wie..., würde ich gerne wissen..."
- Abschweifung für später notieren
  - "Das ist ein wichtiger Punkt. Lassen Sie uns später darauf zurückkommen."

#### Emotionale Reaktionen
- Empathie zeigen, ohne zu werten
  - "Ich sehe, dass dieses Thema Sie bewegt."
- Pause anbieten
  - "Möchten Sie eine kurze Pause machen?"
- Themenwechsel ermöglichen
  - "Wir können auch zu einem anderen Thema übergehen, wenn Sie möchten."

#### Dominante Teilnehmer
- Höflich unterbrechen und lenken
  - "Danke für diese ausführliche Antwort. Um noch andere Aspekte zu beleuchten..."
- Zeitbegrenzungen kommunizieren
  - "Da wir begrenzte Zeit haben, würde ich gerne noch zu... übergehen."
- Fokussierte Fragen stellen
  - "Können Sie in 1-2 Sätzen zusammenfassen...?"

#### Zurückhaltende Teilnehmer
- Einfachere Einstiegsfragen stellen
- Mehr Zeit zum Nachdenken geben
- Bestätigung und Ermutigung bieten
  - "Das ist eine sehr hilfreiche Perspektive."
- Alternativen zur verbalen Kommunikation anbieten
  - "Vielleicht möchten Sie das aufzeichnen oder skizzieren?"

## 3. Analyse von Interviewdaten

### 3.1 Prozess der Interviewanalyse

#### Schritt 1: Vorbereitung der Daten (1-2 Tage nach dem Interview)
1. **Transkription**
   - Vollständige oder selektive Transkription erstellen
   - Automatisierte Transkriptionstools nutzen und korrigieren
   - Einheitliches Format für alle Transkripte verwenden
   - Non-verbale Signale und Kontext dokumentieren

2. **Organisation der Daten**
   - Einheitliche Benennungskonvention für Dateien
   - Zentrale Ablage für alle Interviewdaten
   - Backup-Strategie implementieren
   - Vertraulichkeit und Datenschutz sicherstellen

#### Schritt 2: Erste Analyse (2-3 Tage)
1. **Erstes Durchlesen**
   - Transkripte ohne Unterbrechung durchlesen
   - Erste Eindrücke und Muster notieren
   - Keine detaillierte Kodierung in dieser Phase

2. **Entwicklung des Kodierungsschemas**
   - Basierend auf Forschungsfragen initiales Schema entwickeln
   - Bei induktivem Ansatz: Offenes Kodieren der ersten 2-3 Interviews
   - Bei deduktivem Ansatz: Vordefinierte Kategorien anwenden
   - Kodierungsschema dokumentieren und mit Team abstimmen

#### Schritt 3: Detaillierte Kodierung (3-7 Tage)
1. **Systematische Kodierung**
   - Jedes Transkript Zeile für Zeile kodieren
   - Konsistente Anwendung des Kodierungsschemas
   - Neue Codes bei Bedarf hinzufügen
   - Kodierungsentscheidungen dokumentieren

2. **Überprüfung und Iteration**
   - Stichprobenartige Überprüfung durch Kollegen
   - Kodierungsschema bei Bedarf anpassen
   - Zweite Kodierungsrunde für frühe Interviews

#### Schritt 4: Musteridentifikation (2-3 Tage)
1. **Thematische Analyse**
   - Verwandte Codes gruppieren
   - Themen und Unterthemen identifizieren
   - Beziehungen zwischen Themen visualisieren
   - Häufigkeiten und Verteilungen analysieren

2. **Kontrastanalyse**
   - Unterschiede zwischen Teilnehmergruppen identifizieren
   - Abweichende Fälle analysieren
   - Muster über verschiedene Kontexte hinweg vergleichen

#### Schritt 5: Interpretation und Synthese (2-4 Tage)
1. **Tiefere Interpretation**
   - Bedeutung der identifizierten Muster analysieren
   - Verbindungen zu Forschungsfragen herstellen
   - Theoretische Konzepte einbeziehen
   - Alternative Erklärungen erwägen

2. **Synthese der Erkenntnisse**
   - Haupterkenntnisse zusammenfassen
   - Hierarchie der Erkenntnisse erstellen
   - Verbindungen zu anderen Datenquellen herstellen
   - Implikationen für Design ableiten

#### Schritt 6: Validierung (1-2 Tage)
1. **Interne Validierung**
   - Überprüfung durch Teammitglieder
   - Suche nach widersprüchlichen Evidenzen
   - Reflexion über potenzielle Biases

2. **Externe Validierung (optional)**
   - Member-Checking mit Teilnehmern
   - Validierung durch Domänenexperten
   - Triangulation mit anderen Datenquellen

### 3.2 Vorlage für ein Kodierungsschema

```
# Kodierungsschema: [Projektname]

## Metadaten
- Projekt: [Projektname]
- Erstellt von: [Name]
- Datum: [Datum]
- Version: [Version]

## Anleitung zur Verwendung
- Jedes Segment kann mehrere Codes erhalten
- Bei Unsicherheit Segment mit "Prüfen" markieren
- Neue Codes dokumentieren und dem Team mitteilen

## Primäre Codes

### 1. Nutzerbedürfnisse
- 1.1 Funktionale Bedürfnisse
  - 1.1.1 Effizienz
  - 1.1.2 Kontrolle
  - 1.1.3 Flexibilität
- 1.2 Emotionale Bedürfnisse
  - 1.2.1 Sicherheit
  - 1.2.2 Zugehörigkeit
  - 1.2.3 Anerkennung
- 1.3 Kontextuelle Bedürfnisse
  - 1.3.1 Mobilität
  - 1.3.2 Soziale Umgebung
  - 1.3.3 Physische Umgebung

### 2. Nutzungsmuster
- 2.1 Häufigkeit
- 2.2 Dauer
- 2.3 Kontext
- 2.4 Sequenz
- 2.5 Workarounds

### 3. Schmerzpunkte
- 3.1 Usability-Probleme
- 3.2 Funktionale Lücken
- 3.3 Informationsprobleme
- 3.4 Technische Probleme
- 3.5 Prozessprobleme

### 4. Positive Erfahrungen
- 4.1 Zufriedenheit
- 4.2 Begeisterung
- 4.3 Überraschung
- 4.4 Erleichterung

### 5. Verbesserungsvorschläge
- 5.1 Explizite Vorschläge
- 5.2 Implizite Hinweise
- 5.3 Priorisierungen

## Sekundäre Codes (kontextabhängig)

### 6. Produktspezifische Aspekte
- 6.1 Feature A
- 6.2 Feature B
- 6.3 Feature C

### 7. Nutzertypen
- 7.1 Anfänger
- 7.2 Gelegenheitsnutzer
- 7.3 Fortgeschrittene
- 7.4 Experten

## Kodierungsbeispiele
- "Ich finde es frustrierend, wenn ich jedes Mal drei Klicks brauche, um zur Hauptseite zurückzukehren." → 3.1 Usability-Probleme, 5.2 Implizite Hinweise
- "Ich nutze die App hauptsächlich unterwegs im Bus, da habe ich oft schlechtes Internet." → 1.3.1 Mobilität, 2.3 Kontext, 3.4 Technische Probleme
```

### 3.3 Techniken zur Ableitung von Design-Implikationen

#### Schritt 1: Identifikation von Schlüsselerkenntnissen
1. Priorisieren Sie Erkenntnisse nach:
   - Häufigkeit (wie oft wurde es erwähnt?)
   - Intensität (wie stark war die emotionale Reaktion?)
   - Relevanz für Forschungsziele
   - Überraschungswert oder Neuheit

2. Erstellen Sie eine Liste von 5-10 Schlüsselerkenntnissen, die:
   - Klar und spezifisch sind
   - Durch Daten belegt sind
   - Handlungsrelevant sind
   - Verschiedene Aspekte der Nutzererfahrung abdecken

#### Schritt 2: Von Erkenntnissen zu Anforderungen
Für jede Schlüsselerkenntniss:

1. Formulieren Sie das zugrundeliegende Nutzerbedürfnis
   - "Nutzer benötigen..."
   - "Nutzer wollen..."
   - "Nutzer erwarten..."

2. Identifizieren Sie Hindernisse und Förderfaktoren
   - "Nutzer werden behindert durch..."
   - "Nutzer werden unterstützt durch..."

3. Leiten Sie konkrete Anforderungen ab
   - Funktionale Anforderungen
   - Nicht-funktionale Anforderungen (Usability, Performance, etc.)
   - Inhaltliche Anforderungen
   - Kontextuelle Anforderungen

4. Dokumentieren Sie die Verbindung zwischen Erkenntnis und Anforderung

#### Schritt 3: Entwicklung von Design-Prinzipien
1. Identifizieren Sie übergreifende Muster in den Anforderungen

2. Formulieren Sie 3-7 Design-Prinzipien, die:
   - Handlungsleitend sind
   - Spezifisch genug für das Projekt sind
   - Allgemein genug für verschiedene Design-Entscheidungen sind
   - Priorisierung ermöglichen

3. Validieren Sie die Prinzipien mit dem Team

#### Schritt 4: Ideengenerierung
1. Organisieren Sie einen Workshop mit dem Design-Team

2. Präsentieren Sie Schlüsselerkenntnisse, Anforderungen und Prinzipien

3. Nutzen Sie strukturierte Ideation-Methoden:
   - How-Might-We-Fragen für jede Anforderung
   - Crazy 8s für schnelle Ideengenerierung
   - Affinity Mapping zur Gruppierung ähnlicher Ideen

4. Priorisieren Sie Ideen basierend auf:
   - Übereinstimmung mit Design-Prinzipien
   - Technische Machbarkeit
   - Business-Wert
   - Innovationspotenzial

#### Schritt 5: Dokumentation und Kommunikation
1. Erstellen Sie ein Insight-to-Action-Framework:
   - Spalte 1: Schlüsselerkenntnis
   - Spalte 2: Nutzerbedürfnis
   - Spalte 3: Design-Anforderung
   - Spalte 4: Design-Ideen
   - Spalte 5: Nächste Schritte

2. Visualisieren Sie Erkenntnisse durch:
   - Zitate und Anekdoten
   - Nutzerreise-Karten
   - Empathie-Karten
   - Personas (falls relevant)

3. Präsentieren Sie die Ergebnisse dem breiteren Team

### 3.4 Vorlage für einen Interviewanalysebericht

```
# Interviewanalysebericht: [Projektname]

## Zusammenfassung
[1-2 Absätze mit den wichtigsten Erkenntnissen und Implikationen]

## 1. Einleitung
### 1.1 Hintergrund und Ziele
[Kurze Beschreibung des Projekts und der Forschungsziele]

### 1.2 Methodik
- Interviewtyp: [z.B. Semi-strukturierte Interviews]
- Anzahl der Interviews: [X]
- Teilnehmerprofile: [Kurze Beschreibung der Zielgruppe(n)]
- Zeitraum: [Datum]
- Analysemethode: [z.B. Thematische Analyse]

## 2. Schlüsselerkenntnisse
### 2.1 [Thema 1]
[Beschreibung der Erkenntnis mit 1-2 repräsentativen Zitaten]
- Unterpunkt 1
- Unterpunkt 2

### 2.2 [Thema 2]
[Beschreibung der Erkenntnis mit 1-2 repräsentativen Zitaten]
- Unterpunkt 1
- Unterpunkt 2

### 2.3 [Thema 3]
[Beschreibung der Erkenntnis mit 1-2 repräsentativen Zitaten]
- Unterpunkt 1
- Unterpunkt 2

## 3. Nutzerbedürfnisse
### 3.1 Primäre Bedürfnisse
- [Bedürfnis 1]: [Beschreibung]
- [Bedürfnis 2]: [Beschreibung]

### 3.2 Sekundäre Bedürfnisse
- [Bedürfnis 3]: [Beschreibung]
- [Bedürfnis 4]: [Beschreibung]

## 4. Schmerzpunkte und Herausforderungen
### 4.1 Kritische Probleme
- [Problem 1]: [Beschreibung, Häufigkeit, Auswirkung]
- [Problem 2]: [Beschreibung, Häufigkeit, Auswirkung]

### 4.2 Sekundäre Probleme
- [Problem 3]: [Beschreibung, Häufigkeit, Auswirkung]
- [Problem 4]: [Beschreibung, Häufigkeit, Auswirkung]

## 5. Design-Implikationen
### 5.1 Design-Prinzipien
- [Prinzip 1]: [Beschreibung]
- [Prinzip 2]: [Beschreibung]

### 5.2 Konkrete Anforderungen
- [Anforderung 1]: [Beschreibung, Priorität]
- [Anforderung 2]: [Beschreibung, Priorität]

### 5.3 Design-Ideen
- [Idee 1]: [Beschreibung]
- [Idee 2]: [Beschreibung]

## 6. Segmentspezifische Erkenntnisse (optional)
### 6.1 [Segment 1]
[Spezifische Erkenntnisse für dieses Nutzersegment]

### 6.2 [Segment 2]
[Spezifische Erkenntnisse für dieses Nutzersegment]

## 7. Limitationen und nächste Schritte
### 7.1 Limitationen
[Beschreibung der Einschränkungen dieser Studie]

### 7.2 Empfehlungen für weitere Forschung
[Vorschläge für Folgeuntersuchungen]

### 7.3 Nächste Schritte
[Konkrete nächste Schritte im Projekt]

## Anhänge
- Anhang A: Interviewleitfaden
- Anhang B: Teilnehmerprofile
- Anhang C: Kodierungsschema
- Anhang D: Zusätzliche Zitate
```

## 4. Integration in agile Prozesse

### 4.1 Anpassung von Interviews für agile Entwicklungsumgebungen

#### Micro-Interviews (15-20 Minuten)
- **Fokus**: 1-2 spezifische Forschungsfragen pro Interview
- **Rekrutierung**: Aufbau eines kontinuierlichen Teilnehmerpools
- **Planung**: Feste wöchentliche Zeitfenster für Interviews
- **Dokumentation**: Kurze, actionable Insights statt umfassender Berichte
- **Integration**: Direkte Verbindung zu User Stories und Akzeptanzkriterien

#### Parallele Tracks
1. **Research-Track**:
   - Läuft parallel zum Entwicklungs-Track
   - 1-2 Sprints voraus für proaktive Forschung
   - Eigene Planungs- und Review-Meetings

2. **Integrierte Research-Aktivitäten**:
   - Research-Kapazität in jedem Sprint einplanen
   - UX-Forscher als Teil des Scrum-Teams
   - Research-Aufgaben im Sprint Backlog

#### Kontinuierliche Forschung
- Regelmäßige, kleinere Forschungsaktivitäten statt großer Studien
- Fortlaufende Rekrutierung und Screening
- Aufbau einer Forschungsdatenbank für schnellen Zugriff
- Iterative Verfeinerung der Forschungsfragen

### 4.2 Zeitplan für UX-Interviews in agilen Sprints

#### Zwei-Wochen-Sprint-Modell

**Woche 1**
- **Tag 1-2 (Sprint-Beginn)**:
  - Forschungsfragen basierend auf Sprint-Planung definieren
  - Interviewleitfaden erstellen
  - Teilnehmerrekrutierung starten

- **Tag 3-4**:
  - 2-3 Interviews durchführen
  - Schnelle Analyse der ersten Erkenntnisse
  - Erste Insights an das Team kommunizieren

- **Tag 5**:
  - Weitere 1-2 Interviews
  - Mid-Sprint-Update für das Team

**Woche 2**
- **Tag 6-7**:
  - Abschließende Analyse
  - Dokumentation der Erkenntnisse
  - Ableitung von Design-Implikationen

- **Tag 8-9**:
  - Präsentation der Erkenntnisse im Team
  - Integration in den Design-Prozess
  - Vorbereitung für nächsten Sprint

- **Tag 10 (Sprint-Ende)**:
  - Reflexion im Sprint-Review
  - Planung der Forschung für nächsten Sprint

### 4.3 Effektive Kommunikation von Interviewergebnissen

#### Formate für schnelle Kommunikation
1. **Research-Snippets**:
   - 1-seitige Zusammenfassungen
   - 3-5 Kernerkenntnisse
   - 1-2 repräsentative Zitate
   - Klare Design-Implikationen

2. **Insight-Karten**:
   - Einzelne Erkenntnisse auf Karten
   - Physisch oder digital (z.B. Miro, Trello)
   - Kategorisierung nach Themen
   - Verknüpfung mit User Stories

3. **Stand-up-Updates**:
   - 2-Minuten-Updates in Daily Stand-ups
   - Fokus auf aktuelle Erkenntnisse
   - Verbindung zu aktuellen Entwicklungsaufgaben

#### Kollaborative Analyse
1. **Team-Analyse-Workshops**:
   - 60-90 Minuten
   - Gemeinsames Durchgehen ausgewählter Interviewausschnitte
   - Kollaboratives Affinity Mapping
   - Gemeinsame Ableitung von Design-Implikationen

2. **Pair-Research**:
   - UX-Forscher + Entwickler/Designer
   - Gemeinsame Durchführung von 1-2 Interviews
   - Direkte Erfahrung statt nur Berichte

#### Dokumentation und Wissensmanagement
1. **Research-Repository**:
   - Zentrale Ablage aller Forschungsergebnisse
   - Suchbare und filterbare Datenbank
   - Verknüpfung mit Produktentwicklung
   - Regelmäßige Updates und Pflege

2. **Research-Wall**:
   - Physische oder digitale Visualisierung
   - Kontinuierliche Aktualisierung
   - Zentrale Anlaufstelle für Erkenntnisse
   - Verbindung zu Roadmap und Backlog

## 5. Qualitätssicherung und Evaluation

### 5.1 Checkliste zur Qualitätssicherung von Interviews

#### Vor dem Interview
- [ ] Forschungsziele sind klar definiert und dokumentiert
- [ ] Interviewleitfaden wurde von mindestens einem Kollegen geprüft
- [ ] Pilottest wurde durchgeführt und Anpassungen vorgenommen
- [ ] Teilnehmerauswahl entspricht den Zielgruppen
- [ ] Technische Ausrüstung wurde getestet
- [ ] Einverständniserklärung ist vorbereitet
- [ ] Interviewer ist mit dem Leitfaden vertraut

#### Während des Interviews
- [ ] Einverständniserklärung wurde eingeholt
- [ ] Aufnahme funktioniert
- [ ] Interviewer bleibt neutral und nicht-direktiv
- [ ] Alle Kernfragen werden abgedeckt
- [ ] Angemessene Nachfragen werden gestellt
- [ ] Zeitmanagement wird eingehalten
- [ ] Non-verbale Signale werden beachtet

#### Nach dem Interview
- [ ] Reflexionsnotizen wurden unmittelbar erstellt
- [ ] Aufnahmen sind gesichert und benannt
- [ ] Transkription ist vollständig und korrekt
- [ ] Kodierung folgt dem dokumentierten Schema
- [ ] Mindestens 20% der Kodierung wurde von einem zweiten Forscher überprüft
- [ ] Abweichende Fälle wurden analysiert
- [ ] Erkenntnisse sind auf die Forschungsfragen bezogen
- [ ] Design-Implikationen sind klar und handlungsorientiert

### 5.2 Bewertung der Interviewqualität

#### Kriterien für die Bewertung von Interviews
1. **Relevanz**:
   - Inwieweit beantwortet das Interview die Forschungsfragen?
   - Liefert es neue, relevante Erkenntnisse?

2. **Tiefe**:
   - Geht das Interview über oberflächliche Antworten hinaus?
   - Wurden Themen ausreichend vertieft?

3. **Breite**:
   - Wurden alle relevanten Themenbereiche abgedeckt?
   - Gibt es unerwartete Themen, die aufgetaucht sind?

4. **Interviewführung**:
   - War der Interviewer neutral und nicht-direktiv?
   - Wurden angemessene Nachfragen gestellt?
   - War die Gesprächsatmosphäre förderlich?

5. **Teilnehmerengagement**:
   - War der Teilnehmer offen und mitteilsam?
   - Gab es Anzeichen für soziale Erwünschtheit oder andere Biases?

#### Bewertungsbogen für Interviews

```
# Interview-Qualitätsbewertung

Interview-ID: ___________
Interviewer: ___________
Bewerter: ___________
Datum: ___________

Bewertungsskala: 1 (unzureichend) bis 5 (hervorragend)

## 1. Relevanz
Bewertung: [ ]
Kommentar:
___________

## 2. Tiefe
Bewertung: [ ]
Kommentar:
___________

## 3. Breite
Bewertung: [ ]
Kommentar:
___________

## 4. Interviewführung
Bewertung: [ ]
Kommentar:
___________

## 5. Teilnehmerengagement
Bewertung: [ ]
Kommentar:
___________

## Gesamtbewertung
Bewertung: [ ]
Kommentar:
___________

## Stärken des Interviews:
___________

## Verbesserungspotenzial:
___________

## Empfehlungen für zukünftige Interviews:
___________
```

### 5.3 Kontinuierliche Verbesserung von Interviewpraktiken

#### Reflexionsprozess nach jedem Interviewzyklus
1. **Team-Retrospektive**:
   - Was hat gut funktioniert?
   - Was könnte verbessert werden?
   - Welche Anpassungen sollten für den nächsten Zyklus vorgenommen werden?

2. **Methodische Reflexion**:
   - War die gewählte Interviewmethode angemessen?
   - Haben die Fragen die gewünschten Informationen geliefert?
   - Waren die Analysemethoden effektiv?

3. **Dokumentation von Lessons Learned**:
   - Erfolgreiche Praktiken
   - Herausforderungen und Lösungen
   - Anpassungen für zukünftige Projekte

#### Maßnahmen zur kontinuierlichen Verbesserung
1. **Skill-Building**:
   - Regelmäßige Schulungen für Interviewer
   - Peer-Feedback zu Interviewtechniken
   - Gemeinsames Lernen aus Beispielen

2. **Methodische Weiterentwicklung**:
   - Experimentieren mit neuen Interviewtechniken
   - Anpassung von Leitfäden basierend auf Erfahrungen
   - Optimierung von Analyseprozessen

3. **Wissensmanagement**:
   - Aufbau einer internen Wissensdatenbank
   - Dokumentation von Best Practices
   - Austausch zwischen Teams und Projekten

## 6. Ressourcen und Vorlagen

### 6.1 Interviewleitfaden-Vorlagen für verschiedene UX-Kontexte

#### Vorlage 1: Explorative Interviews zur Bedarfsanalyse
[Siehe Abschnitt 1.2 für eine detaillierte Vorlage]

#### Vorlage 2: Kontextuelle Interviews
```
# Kontextuelles Interview: [Projektname]

## Vorbereitung
- Datum und Uhrzeit: [Datum, Uhrzeit]
- Ort: [Arbeitsplatz/Zuhause des Teilnehmers]
- Dauer: ca. 60-90 Minuten
- Mitzubringen: Aufnahmegerät, Kamera, Notizbuch, Skizzenpapier

## 1. Einführung (5-10 Minuten)
- Vorstellung und Dank
- Erklärung des kontextuellen Interviews:
  "Ich möchte Sie heute bei Ihrer Arbeit/Nutzung beobachten und dabei Fragen stellen. Bitte arbeiten Sie wie gewohnt und denken Sie laut, wenn möglich."
- Einverständnis für Aufnahme und Fotos einholen
- Klären, welche Aktivitäten beobachtet werden sollen

## 2. Kontextuelle Beobachtung (30-45 Minuten)
### Umgebungskontext
- Notieren Sie die physische Umgebung:
  - Arbeitsplatzgestaltung
  - Vorhandene Geräte und Tools
  - Umgebungsfaktoren (Lärm, Licht, etc.)

### Aktivitätsbeobachtung
- Bitten Sie den Teilnehmer, die relevante Aktivität durchzuführen
- Beobachtungsfokus:
  - Sequenz der Handlungen
  - Verwendete Tools und Ressourcen
  - Interaktion mit anderen Personen
  - Probleme und Workarounds
  - Emotionale Reaktionen

### Kontextuelle Fragen (während der Beobachtung)
- "Können Sie erklären, was Sie gerade tun?"
- "Warum machen Sie es auf diese Weise?"
- "Ist das der übliche Ablauf?"
- "Was passiert als nächstes?"
- "Welche Probleme treten dabei auf?"

## 3. Nachbesprechung (15-20 Minuten)
- Klärung von Unklarheiten aus der Beobachtung
- Vertiefende Fragen:
  - "Wie haben Sie gelernt, diese Aufgabe so durchzuführen?"
  - "Was würden Sie an diesem Prozess verbessern wollen?"
  - "Wie oft führen Sie diese Aktivität durch?"
  - "Wie unterscheidet sich die heutige Durchführung vom Normalfall?"

## 4. Artefakt-Analyse (10-15 Minuten)
- Bitten Sie um Erlaubnis, relevante Artefakte zu fotografieren:
  - Notizen oder Checklisten
  - Selbst erstellte Hilfsmittel
  - Anpassungen an Tools oder Umgebung
- Fragen zu den Artefakten:
  - "Wofür verwenden Sie dieses [Artefakt]?"
  - "Wie haben Sie es entwickelt/angepasst?"
  - "Wie hilft es Ihnen bei Ihrer Arbeit?"

## 5. Abschluss (5 Minuten)
- Zusammenfassung der Hauptbeobachtungen
- Dank für die Teilnahme
- Nächste Schritte erläutern
- Incentive übergeben

## Nachbereitung (direkt nach dem Interview)
- Skizze der Umgebung erstellen
- Fotos organisieren und beschriften
- Reflexionsnotizen erstellen:
  - Haupterkenntnisse
  - Überraschende Beobachtungen
  - Methodische Anpassungen für zukünftige Interviews
```

#### Vorlage 3: Interviews für Usability-Tests
```
# Usability-Test Interview: [Projektname]

## Vorbereitung
- Produkt/Prototyp: [Name/Version]
- Testumgebung: [Labor/Remote/Vor Ort]
- Aufgaben: [Liste der Testaufgaben]
- Dauer: ca. 60 Minuten

## 1. Einführung (5-10 Minuten)
- Begrüßung und Dank
- Zweck des Tests erklären:
  "Wir testen das Produkt, nicht Sie. Es gibt keine falschen Antworten."
- Think-Aloud-Methode erklären:
  "Bitte sprechen Sie während des Tests laut aus, was Sie denken, tun und fühlen."
- Rolle des Moderators erklären:
  "Ich werde Sie durch den Test führen, aber nicht helfen können, da wir sehen wollen, wie das Produkt ohne Hilfe funktioniert."
- Einverständniserklärung und Aufnahme

## 2. Pre-Test-Interview (5-10 Minuten)
- Hintergrundfragen:
  - "Welche Erfahrungen haben Sie mit ähnlichen Produkten?"
  - "Wie würden Sie typischerweise [relevante Aufgabe] erledigen?"
  - "Welche Erwartungen haben Sie an [Produkt]?"

## 3. Testdurchführung (30-40 Minuten)
[Für jede Aufgabe:]
- Aufgabe vorstellen:
  "Bitte versuchen Sie, [Aufgabenbeschreibung]."
- Beobachtung während der Durchführung
- Neutrale Prompts für Think-Aloud:
  - "Was denken Sie gerade?"
  - "Was erwarten Sie, was als nächstes passiert?"
- Nach jeder Aufgabe:
  - "Wie schwierig fanden Sie diese Aufgabe auf einer Skala von 1-5?"
  - "Was hat gut funktioniert? Was war schwierig?"

## 4. Post-Test-Interview (10-15 Minuten)
- Allgemeine Eindrücke:
  - "Was sind Ihre allgemeinen Eindrücke von [Produkt]?"
  - "Was hat Ihnen besonders gut gefallen?"
  - "Was hat Sie frustriert oder verwirrt?"

- Spezifische Nachfragen:
  - "Wir haben beobachtet, dass Sie bei [Situation] gezögert haben. Können Sie erklären warum?"
  - "Sie haben [Workaround] verwendet. Was hat Sie dazu veranlasst?"

- Verbesserungsvorschläge:
  - "Welche Verbesserungen würden Sie vorschlagen?"
  - "Was hat Ihrer Meinung nach gefehlt?"

- Abschließende Fragen:
  - "Auf einer Skala von 1-10, wie wahrscheinlich würden Sie dieses Produkt nutzen/empfehlen?"
  - "Haben Sie noch weitere Kommentare oder Fragen?"

## 5. Abschluss (2-5 Minuten)
- Dank für die Teilnahme
- Incentive übergeben
- Nächste Schritte erläutern

## Nachbereitung
- Usability-Probleme dokumentieren:
  - Schweregrad
  - Betroffene Aufgaben
  - Beobachtete Auswirkungen
  - Mögliche Ursachen
- Erfolge und positive Aspekte notieren
- Verbesserungsvorschläge sammeln
```

### 6.2 Checklisten und Vorlagen für die Interviewanalyse

#### Checkliste für die Transkription
- [ ] Konsistentes Format für alle Transkripte festlegen
- [ ] Sprecherwechsel klar kennzeichnen
- [ ] Non-verbale Signale dokumentieren (Pausen, Lachen, Seufzen, etc.)
- [ ] Unverständliche Passagen markieren
- [ ] Zeitstempel für wichtige Momente einfügen
- [ ] Vertrauliche Informationen anonymisieren
- [ ] Transkripte Korrektur lesen
- [ ] Einheitliche Dateinamenkonvention verwenden
- [ ] Backup der Transkripte erstellen

#### Vorlage für Kodierungsnotizen
```
# Kodierungsnotizen: [Interview-ID]

## Metadaten
- Kodierer: [Name]
- Datum: [Datum]
- Kodierungsdurchgang: [Erst-/Zweitkodierung]

## Neue Codes
- [Code-Name]: [Definition] - entstanden aus [Textstelle]
- [Code-Name]: [Definition] - entstanden aus [Textstelle]

## Anpassungen bestehender Codes
- [Code-Name]: [Alte Definition] → [Neue Definition]
- [Code-Name]: [Alte Definition] → [Neue Definition]

## Schwierige Kodierungsentscheidungen
- [Textstelle]: Schwierigkeit bei der Entscheidung zwischen [Code A] und [Code B]
  - Entscheidung: [Gewählter Code]
  - Begründung: [Begründung]

## Auffällige Muster
- [Beschreibung des Musters]
- [Beschreibung des Musters]

## Fragen für das Team
- [Frage]
- [Frage]

## Nächste Schritte
- [Nächster Schritt]
- [Nächster Schritt]
```

#### Vorlage für Thematische Analyse
```
# Thematische Analyse: [Projektname]

## Thema 1: [Thementitel]
### Beschreibung
[Kurze Beschreibung des Themas und seiner Bedeutung]

### Unterthemen
1. **[Unterthema 1.1]**
   - Häufigkeit: [X von Y Interviews]
   - Schlüsselzitate:
     - "[Zitat]" - [Teilnehmer-ID]
     - "[Zitat]" - [Teilnehmer-ID]
   - Verbindungen zu anderen Themen:
     - [Thema X]: [Beschreibung der Verbindung]

2. **[Unterthema 1.2]**
   - Häufigkeit: [X von Y Interviews]
   - Schlüsselzitate:
     - "[Zitat]" - [Teilnehmer-ID]
     - "[Zitat]" - [Teilnehmer-ID]
   - Verbindungen zu anderen Themen:
     - [Thema X]: [Beschreibung der Verbindung]

### Variationen nach Nutzergruppen
- [Gruppe A]: [Spezifische Ausprägung des Themas]
- [Gruppe B]: [Spezifische Ausprägung des Themas]

### Implikationen
- [Implikation 1]
- [Implikation 2]

## Thema 2: [Thementitel]
[Gleiche Struktur wie oben]

## Übergreifende Muster und Beziehungen
- [Muster 1]: [Beschreibung]
- [Muster 2]: [Beschreibung]

## Abweichende Fälle
- [Fall 1]: [Beschreibung und mögliche Erklärung]
- [Fall 2]: [Beschreibung und mögliche Erklärung]

## Offene Fragen und weiterer Forschungsbedarf
- [Frage 1]
- [Frage 2]
```

### 6.3 Werkzeuge und Software für Interviews

#### Aufnahme und Transkription
1. **Audio-Aufnahme**:
   - Zoom (für Remote-Interviews)
   - Otter.ai (Aufnahme mit Live-Transkription)
   - Voice Recorder Pro (für mobile Aufnahmen)
   - Audacity (für Audiobearbeitung)

2. **Video-Aufnahme**:
   - Zoom (für Remote-Interviews)
   - Camtasia (für Bildschirmaufnahmen)
   - OBS Studio (Open-Source-Alternative)

3. **Transkription**:
   - Otter.ai (automatische Transkription)
   - Trint (automatische Transkription mit Editierfunktion)
   - Express Scribe (manuelle Transkription)
   - NVivo Transcription (für Forschungsprojekte)

#### Analyse-Tools
1. **Qualitative Datenanalyse**:
   - NVivo (umfassend, aber komplex)
   - ATLAS.ti (visuell orientiert)
   - MAXQDA (benutzerfreundlich)
   - QDA Miner Lite (kostenlose Option)
   - Taguette (Open Source)

2. **Kollaborative Analyse**:
   - Miro (für visuelle Zusammenarbeit)
   - MURAL (für digitale Workshops)
   - Notion (für Dokumentation und Zusammenarbeit)
   - Google Docs (für einfache kollaborative Analyse)

#### Remote-Interview-Tools
1. **Videokonferenz-Plattformen**:
   - Zoom (stabil, weit verbreitet)
   - Microsoft Teams (gut für Unternehmensumgebungen)
   - Google Meet (einfach zu nutzen)
   - Whereby (keine Installation nötig)

2. **Spezialisierte UX-Forschungsplattformen**:
   - UserZoom (End-to-End-Lösung)
   - Lookback (für moderierten Remote-Tests)
   - Optimal Workshop (für verschiedene UX-Methoden)
   - UserTesting (für schnelles Feedback)

#### Rekrutierungs-Tools
1. **Teilnehmerrekrutierung**:
   - UserInterviews
   - Respondent
   - Ethnio
   - Userlytics
   - Eigene Datenbank mit Airtable oder Google Sheets

2. **Screening und Planung**:
   - Calendly (für Terminplanung)
   - Typeform oder Google Forms (für Screening)
   - Doodle (für Terminkoordination)

## 7. Ethische Richtlinien für Interviews

### 7.1 Ethische Grundprinzipien

#### Respekt für Autonomie und Würde
- Teilnehmer als Partner, nicht als Forschungsobjekte behandeln
- Kulturelle und individuelle Unterschiede respektieren
- Recht auf Selbstbestimmung achten
- Privatsphäre und Vertraulichkeit wahren

#### Informierte Einwilligung
- Vollständige Transparenz über Zweck und Verwendung der Daten
- Verständliche Sprache ohne Fachjargon
- Freiwilligkeit der Teilnahme betonen
- Recht auf Abbruch jederzeit gewährleisten
- Dokumentation der Einwilligung

#### Schutz vor Schaden
- Psychisches Wohlbefinden der Teilnehmer sicherstellen
- Sensible Themen behutsam behandeln
- Angemessene Unterstützung bei emotionalen Reaktionen bieten
- Übermäßigen Zeitaufwand vermeiden

#### Fairness und Gerechtigkeit
- Angemessene Vergütung für die Zeit und den Beitrag
- Inklusive Rekrutierung verschiedener Gruppen
- Barrierefreier Zugang zu Interviews
- Faire Repräsentation in der Analyse und Berichterstattung

### 7.2 Vorlage für eine Einverständniserklärung

```
# Einverständniserklärung für UX-Forschungsinterview

## Projektinformationen
Projekttitel: [Titel]
Durchführende Organisation: [Organisation]
Ansprechpartner: [Name, E-Mail, Telefon]

## Zweck der Forschung
[Kurze, verständliche Beschreibung des Forschungszwecks]

## Ablauf des Interviews
- Das Interview wird etwa [X] Minuten dauern.
- Wir werden Fragen zu [Themen] stellen.
- [Weitere relevante Informationen zum Ablauf]

## Datenerhebung und -verwendung
- Das Interview wird [audio/video] aufgezeichnet.
- Die Aufzeichnungen werden für [Zweck] verwendet.
- Ihre Daten werden [Speicherdauer] aufbewahrt.
- Zugriff auf die Daten haben nur [Personenkreis].
- Die Ergebnisse werden [Art der Veröffentlichung] veröffentlicht.

## Vertraulichkeit und Anonymität
- Alle Informationen werden vertraulich behandelt.
- Ihre Identität wird in allen Berichten anonymisiert.
- Direkte Zitate werden nur mit Ihrer Zustimmung und anonymisiert verwendet.
- [Weitere Maßnahmen zum Datenschutz]

## Freiwilligkeit
- Ihre Teilnahme ist vollständig freiwillig.
- Sie können jederzeit ohne Angabe von Gründen abbrechen.
- Sie können die Beantwortung einzelner Fragen ablehnen.
- Ein Abbruch hat keine negativen Konsequenzen für Sie.

## Vergütung
- Als Dankeschön für Ihre Teilnahme erhalten Sie [Incentive].
- Die Vergütung erhalten Sie auch bei vorzeitigem Abbruch.

## Einverständniserklärung

Ich bestätige, dass:
- Ich die obigen Informationen gelesen und verstanden habe.
- Ich Gelegenheit hatte, Fragen zu stellen, und diese zufriedenstellend beantwortet wurden.
- Ich freiwillig an diesem Interview teilnehme.
- Ich der Aufzeichnung des Interviews zustimme.
- Ich verstehe, dass anonymisierte Zitate in Berichten verwendet werden können.

Name des Teilnehmers: ________________________

Unterschrift: ________________________ Datum: ____________

Name des Forschers: ________________________

Unterschrift: ________________________ Datum: ____________
```

### 7.3 Datenschutz und Vertraulichkeit

#### Datenschutzmaßnahmen
1. **Vor dem Interview**:
   - Datenschutzerklärung in klarer Sprache vorbereiten
   - Einverständniserklärung einholen
   - Teilnehmer über Aufzeichnungen informieren
   - Opt-out-Möglichkeiten erklären

2. **Während des Interviews**:
   - Nur notwendige persönliche Daten erfassen
   - Bei sensiblen Themen Aufzeichnung pausieren anbieten
   - Teilnehmer an Vertraulichkeit erinnern

3. **Nach dem Interview**:
   - Daten sicher speichern (Verschlüsselung, Zugriffsschutz)
   - Persönliche Identifikatoren von Forschungsdaten trennen
   - Pseudonymisierung/Anonymisierung durchführen
   - Aufbewahrungsfristen einhalten

#### Anonymisierungsprozess
1. **Direkte Identifikatoren entfernen**:
   - Namen durch Codes oder Pseudonyme ersetzen
   - Kontaktdaten löschen oder separat speichern
   - Gesichter in Videos verpixeln (falls nötig)
   - Stimmen in Audioaufnahmen verändern (falls nötig)

2. **Indirekte Identifikatoren behandeln**:
   - Spezifische Orte verallgemeinern
   - Ungewöhnliche Berufe oder Positionen generalisieren
   - Einzigartige Erfahrungen abstrahieren
   - Kombinationen von Merkmalen prüfen, die Identifikation ermöglichen könnten

3. **Zitate prüfen**:
   - Auf identifizierende Sprache oder Inhalte prüfen
   - Sprachliche Besonderheiten neutralisieren
   - Bei Bedarf Zitate umformulieren unter Beibehaltung des Inhalts

4. **Dokumentation**:
   - Anonymisierungsprozess dokumentieren
   - Zuordnungsschlüssel sicher und getrennt aufbewahren
   - Regelmäßige Überprüfung der Anonymisierung

### 7.4 Umgang mit sensiblen Themen und vulnerablen Gruppen

#### Vorbereitung für sensible Themen
1. **Risikobewertung**:
   - Potenzielle emotionale Belastungen identifizieren
   - Triggerpunkte antizipieren
   - Angemessene Unterstützungsmaßnahmen planen

2. **Interviewleitfaden anpassen**:
   - Sensible Themen behutsam einführen
   - Alternative Formulierungen vorbereiten
   - Ausstiegspunkte einplanen

3. **Interviewer-Training**:
   - Schulung zu sensiblen Themen
   - Umgang mit emotionalen Reaktionen
   - Deeskalationstechniken

#### Während des Interviews
1. **Einführung**:
   - Sensible Themen vorab ankündigen
   - Recht auf Nicht-Beantwortung betonen
   - Pausenmöglichkeiten explizit anbieten

2. **Gesprächsführung**:
   - Empathische, nicht-wertende Haltung
   - Aktives Zuhören und Validierung
   - Respektvolle Sprache und Formulierungen
   - Anzeichen von Unbehagen beachten

3. **Bei emotionalen Reaktionen**:
   - Reaktion anerkennen und normalisieren
   - Pause anbieten
   - Themenwechsel ermöglichen
   - Bei Bedarf Interview beenden

#### Besondere Rücksichten für vulnerable Gruppen
1. **Kinder und Jugendliche**:
   - Elterliche Einwilligung einholen
   - Altersgerechte Sprache und Methoden
   - Kürzere Interviewdauer
   - Anwesenheit einer Vertrauensperson ermöglichen

2. **Ältere Menschen**:
   - Barrierefreien Zugang sicherstellen
   - Mehr Zeit einplanen
   - Technische Unterstützung anbieten
   - Auf Ermüdungserscheinungen achten

3. **Menschen mit Behinderungen**:
   - Spezifische Bedürfnisse im Vorfeld klären
   - Barrierefreie Kommunikation sicherstellen
   - Alternative Interviewformate anbieten
   - Assistenztechnologien ermöglichen

4. **Menschen mit psychischen Erkrankungen**:
   - Triggerthemen identifizieren und behutsam behandeln
   - Klare Struktur und Vorhersehbarkeit bieten
   - Unterstützungsmöglichkeiten bereithalten
   - Nachsorge anbieten

#### Nachsorge
1. **Debriefing**:
   - Positive Abschlussfrage stellen
   - Emotionalen Zustand prüfen
   - Für Fragen und Bedenken zur Verfügung stehen

2. **Unterstützungsangebote**:
   - Informationen zu Beratungsstellen bereitstellen
   - Follow-up-Kontakt anbieten
   - Bei Bedarf professionelle Unterstützung vermitteln

3. **Forscher-Selbstfürsorge**:
   - Reflexion und Verarbeitung ermöglichen
   - Supervision oder Peer-Support nutzen
   - Belastungsgrenzen respektieren
