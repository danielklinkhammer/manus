import Link from 'next/link';
import ContentCard from '@/components/ContentCard';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h1 className="text-4xl font-extrabold text-gray-900 sm:text-5xl sm:tracking-tight lg:text-6xl">
            Interviews in UX Design
          </h1>
          <p className="mt-5 max-w-xl mx-auto text-xl text-gray-500">
            Eine umfassende 3-stündige Vorlesung zu Methoden, Anwendung und Best Practices
          </p>
        </div>

        <div className="mt-16">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            <ContentCard 
              title="Vorlesungsinhalte" 
              description="Ausführliche Inhalte der 3-stündigen Vorlesung zu Interviews im UX Design"
              href="/content"
            />
            
            <ContentCard 
              title="Vorlesungsfolien" 
              description="Präsentationsfolien für die Vorlesung mit den wichtigsten Konzepten und Methoden"
              href="/lectures"
            />
            
            <ContentCard 
              title="Praktische Richtlinien" 
              description="Umfassende praktische Handlungsanweisungen für Interviews im UX Design"
              href="/practical-guidelines"
            />
            
            <ContentCard 
              title="Übungsmaterialien" 
              description="Praktische Übungen zur Vertiefung und Anwendung der theoretischen Inhalte"
              href="/exercises"
            />
            
            <ContentCard 
              title="Zusätzliche Ressourcen" 
              description="Weiterführende Literatur, Online-Ressourcen und Tools für Interviews im UX Design"
              href="/resources"
            />
            
            <ContentCard 
              title="Literaturverzeichnis" 
              description="Vollständiges Literaturverzeichnis im Harvard-Stil für alle verwendeten Quellen"
              href="/references"
            />
          </div>
        </div>

        <div className="mt-16 text-center">
          <Link href="/about" className="btn">
            Über diese Vorlesung
          </Link>
        </div>
      </div>
    </div>
  )
}
