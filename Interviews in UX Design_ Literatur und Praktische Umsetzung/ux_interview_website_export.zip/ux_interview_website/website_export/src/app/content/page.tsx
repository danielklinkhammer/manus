import fs from 'fs';
import path from 'path';
import { MDXRemote } from 'next-mdx-remote/rsc';
import remarkGfm from 'remark-gfm';
import rehypeHighlight from 'rehype-highlight';
import PageHeader from '@/components/PageHeader';
import Breadcrumbs from '@/components/Breadcrumbs';

// Funktion zum Extrahieren von Überschriften für das Inhaltsverzeichnis
function extractHeadings(content: string) {
  const headingRegex = /^(#{2,3})\s+(.+)$/gm;
  const headings = [];
  let match;

  while ((match = headingRegex.exec(content)) !== null) {
    const level = match[1].length;
    const title = match[2];
    const id = title.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '');
    
    headings.push({
      id,
      title,
      level
    });
  }

  return headings;
}

const components = {
  h1: (props) => <h1 {...props} className="text-3xl font-bold mt-8 mb-4" />,
  h2: (props) => <h2 {...props} className="text-2xl font-bold mt-6 mb-3 border-b pb-1" id={props.children?.toString().toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '')} />,
  h3: (props) => <h3 {...props} className="text-xl font-bold mt-5 mb-2" id={props.children?.toString().toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '')} />,
  h4: (props) => <h4 {...props} className="text-lg font-bold mt-4 mb-2" />,
  p: (props) => <p {...props} className="my-4" />,
  ul: (props) => <ul {...props} className="list-disc pl-6 my-4" />,
  ol: (props) => <ol {...props} className="list-decimal pl-6 my-4" />,
  li: (props) => <li {...props} className="my-1" />,
  blockquote: (props) => <blockquote {...props} className="border-l-4 border-gray-300 pl-4 italic my-4" />,
  code: (props) => <code {...props} className="bg-gray-100 rounded px-1 py-0.5 font-mono text-sm" />,
  pre: (props) => <pre {...props} className="bg-gray-100 rounded p-4 overflow-x-auto my-4 font-mono text-sm" />,
  table: (props) => <div className="overflow-x-auto my-6"><table {...props} className="min-w-full divide-y divide-gray-300" /></div>,
  th: (props) => <th {...props} className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900 bg-gray-50" />,
  td: (props) => <td {...props} className="px-3 py-4 text-sm text-gray-500 border-b border-gray-200" />,
  hr: () => <hr className="my-8 border-t border-gray-300" />,
};

export default async function ContentPage() {
  const filePath = path.join(process.cwd(), 'src/app/content/page.mdx');
  const source = fs.readFileSync(filePath, 'utf8');
  
  // Extrahiere Überschriften für das Inhaltsverzeichnis
  const headings = extractHeadings(source);
  
  const breadcrumbItems = [
    { label: 'Inhalte', href: '/content' }
  ];
  
  return (
    <div className="max-w-7xl mx-auto">
      <Breadcrumbs items={breadcrumbItems} />
      
      <div className="lg:grid lg:grid-cols-4 lg:gap-8">
        <div className="hidden lg:block lg:col-span-1">
          <div className="sticky top-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Inhaltsverzeichnis</h2>
              <nav className="space-y-1">
                {headings.map((heading, index) => (
                  <a 
                    key={index}
                    href={`#${heading.id}`} 
                    className={`block text-gray-600 hover:text-blue-600 hover:bg-gray-100 px-2 py-1 rounded ${
                      heading.level === 3 ? 'pl-4' : ''
                    }`}
                  >
                    {heading.title}
                  </a>
                ))}
              </nav>
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-3">
          <PageHeader 
            title="Vorlesungsinhalte: Interviews in UX Design" 
            description="Diese Seite enthält die ausführlichen Inhalte der 3-stündigen Vorlesung zu Interviews im UX Design. Die Inhalte sind in verschiedene Abschnitte gegliedert und bieten einen umfassenden Überblick über Methoden, Anwendungen und Best Practices von Interviews im UX-Kontext."
          />
          
          <div className="prose prose-blue max-w-none">
            <MDXRemote 
              source={source} 
              components={components}
              options={{
                mdxOptions: {
                  remarkPlugins: [remarkGfm],
                  rehypePlugins: [rehypeHighlight],
                },
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
